// jads-android/app/src/main/kotlin/com/jads/ui/theme/JadsTheme.kt
// Full replacement — upgraded Military HUD colour system
// Retains existing NavyBackground/Amber foundation, expands with HUD elements

package com.jads.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ── JADS Military HUD Colour Palette ─────────────────────────────────────────
//
// Design rationale:
//   Primary green  — active/safe/go states (ICAO standard green = safe)
//   Amber          — advisory / caution (aviation instrument standard)
//   Red            — violation / blocked / critical (ICAO standard)
//   Deep navy/black — eliminates glare in field operations
//   Scanline effect — subtle CRT texture reinforces HUD aesthetic
//
// Audiences:
//   Drone operators in the field — needs high contrast outdoor readability
//   Evaluators (iDEX/buyers)    — needs to look impressive and unique

object JadsColors {
    // ── Backgrounds ──────────────────────────────────────────────────────────
    val NavyBackground   = Color(0xFF040A06)   // Deepest background — near-black green tint
    val DeepCharcoal     = Color(0xFF080E0A)   // Login gradient end
    val SurfaceDark      = Color(0xFF0C1410)   // Cards, dialogs, sheets
    val SurfaceVariant   = Color(0xFF142018)   // Input fields, list items, tiles
    val SurfaceElevated  = Color(0xFF1A2A1E)   // Elevated cards, modals

    // ── Primary — Operations Green ────────────────────────────────────────────
    val PrimaryGreen     = Color(0xFF00FF88)   // Active, safe, go, NPNT GREEN
    val PrimaryDim       = Color(0xFF1A6640)   // Inactive green elements
    val PrimarySubtle    = Color(0xFF002A1A)   // Green background tint

    // ── Amber — Advisory / Caution ────────────────────────────────────────────
    val Amber            = Color(0xFFFFB800)   // Caution, NPNT YELLOW, advisories
    val AmberDim         = Color(0xFF6B5000)   // Inactive amber
    val AmberSubtle      = Color(0xFF1A1200)   // Amber background tint

    // ── Red — Critical / Blocked ──────────────────────────────────────────────
    val AlertRed         = Color(0xFFFF3B3B)   // Violations, NPNT RED, failures
    val AlertRedDim      = Color(0xFF5A0000)   // Inactive red
    val AlertRedSubtle   = Color(0xFF1A0505)   // Red background tint

    // ── Text ──────────────────────────────────────────────────────────────────
    val TextPrimary      = Color(0xFFC8E6C9)   // Main text — slightly green-tinted white
    val TextSecondary    = Color(0xFF6A8A6E)   // Secondary / labels
    val TextMuted        = Color(0xFF3A5A3E)   // Placeholder, disabled
    val TextInverse      = Color(0xFF040A06)   // Text on coloured backgrounds

    // ── Borders / Dividers ────────────────────────────────────────────────────
    val BorderSubtle     = Color(0xFF142018)   // Very subtle dividers
    val BorderDefault    = Color(0xFF1E3022)   // Standard borders
    val BorderStrong     = Color(0xFF2A4A2E)   // Visible borders

    // ── Special ───────────────────────────────────────────────────────────────
    val HudBlue          = Color(0xFF4A8CFF)   // Informational / neutral
    val HashGreen        = Color(0xFF00E676)   // Hash chain verified display
    val SignatureGold    = Color(0xFFFFD54F)   // ECDSA signature display
    val ScanlineOverlay  = Color(0x04002A10)   // Scanline effect — apply as repeating pattern

    // ── NPNT Classification (direct mapping to ICAO signal colours) ───────────
    val NpntGreen  = PrimaryGreen
    val NpntYellow = Amber
    val NpntRed    = AlertRed

    // ── Invariant verdict colours ─────────────────────────────────────────────
    val InvariantPass    = PrimaryGreen
    val InvariantFail    = AlertRed
    val InvariantAdvisory = Amber
}

// ── Material3 colour scheme built from JADS tokens ───────────────────────────
private val JadsDarkColorScheme = darkColorScheme(
    primary          = JadsColors.PrimaryGreen,
    onPrimary        = JadsColors.TextInverse,
    primaryContainer = JadsColors.PrimarySubtle,
    onPrimaryContainer = JadsColors.PrimaryGreen,

    secondary        = JadsColors.Amber,
    onSecondary      = JadsColors.TextInverse,
    secondaryContainer = JadsColors.AmberSubtle,
    onSecondaryContainer = JadsColors.Amber,

    tertiary         = JadsColors.HudBlue,
    onTertiary       = JadsColors.TextInverse,

    error            = JadsColors.AlertRed,
    onError          = JadsColors.TextInverse,
    errorContainer   = JadsColors.AlertRedSubtle,
    onErrorContainer = JadsColors.AlertRed,

    background       = JadsColors.NavyBackground,
    onBackground     = JadsColors.TextPrimary,

    surface          = JadsColors.SurfaceDark,
    onSurface        = JadsColors.TextPrimary,
    surfaceVariant   = JadsColors.SurfaceVariant,
    onSurfaceVariant = JadsColors.TextSecondary,

    outline          = JadsColors.BorderDefault,
    outlineVariant   = JadsColors.BorderSubtle,
)

@Composable
fun JadsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = JadsDarkColorScheme,
        typography  = JadsTypography,
        content     = content,
    )
}
