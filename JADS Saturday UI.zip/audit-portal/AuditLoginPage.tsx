// jads-audit-portal/src/pages/AuditLoginPage.tsx
// Full replacement — Forensic HUD login

import React, { useState, useEffect } from 'react'
import { useAuditAuth } from '../hooks/useAuditAuth'
import { useNavigate }  from 'react-router-dom'

const AC = {
  bg: '#080706', surface: '#100E0A', border: '#2A2010',
  primary: '#FFB800', dim: '#6B5000', red: '#FF3B3B',
  text: '#F5E6C8', muted: '#7A6A4A',
}

export function AuditLoginPage() {
  const { login, token } = useAuditAuth()
  const navigate = useNavigate()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError]       = useState('')
  const [loading, setLoading]   = useState(false)

  useEffect(() => { if (token) navigate('/missions', { replace: true }) }, [token])

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      await login(username.trim(), password)
      navigate('/missions', { replace: true })
    } catch {
      setError('ACCESS DENIED — CREDENTIALS NOT ACCEPTED')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: AC.bg,
      backgroundImage: `
        radial-gradient(ellipse at 30% 60%, #1A1000 0%, transparent 60%),
        repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(255,184,0,0.01) 2px, rgba(255,184,0,0.01) 4px)
      `,
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      fontFamily: 'monospace', padding: '20px',
    }}>
      {/* Corner marks */}
      {[
        { top: '20px', left: '20px', borderTop: `2px solid ${AC.dim}`, borderLeft: `2px solid ${AC.dim}` },
        { top: '20px', right: '20px', borderTop: `2px solid ${AC.dim}`, borderRight: `2px solid ${AC.dim}` },
        { bottom: '20px', left: '20px', borderBottom: `2px solid ${AC.dim}`, borderLeft: `2px solid ${AC.dim}` },
        { bottom: '20px', right: '20px', borderBottom: `2px solid ${AC.dim}`, borderRight: `2px solid ${AC.dim}` },
      ].map((s, i) => <div key={i} style={{ position: 'fixed', width: '40px', height: '40px', ...s }} />)}

      <div style={{
        position: 'fixed', top: 0, left: 0, right: 0,
        padding: '8px 20px',
        borderBottom: `1px solid ${AC.border}`,
        display: 'flex', justifyContent: 'space-between',
        fontSize: '10px', color: AC.muted,
        background: `${AC.surface}CC`,
      }}>
        <span style={{ color: AC.primary }}>⚖ JADS FORENSIC AUDIT ACCESS</span>
        <span>AUTHORISED PERSONNEL ONLY</span>
      </div>

      <div style={{
        width: '100%', maxWidth: '400px',
        background: AC.surface,
        border: `1px solid ${AC.border}`,
        borderTop: `2px solid ${AC.primary}`,
        borderRadius: '4px',
        overflow: 'hidden',
        boxShadow: `0 0 60px ${AC.primary}15`,
      }}>
        <div style={{ padding: '28px', borderBottom: `1px solid ${AC.border}`, textAlign: 'center' }}>
          <div style={{
            width: '56px', height: '56px',
            border: `2px solid ${AC.primary}`,
            borderRadius: '6px',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 16px',
            color: AC.primary, fontSize: '22px',
            boxShadow: `0 0 20px ${AC.primary}44`,
            fontFamily: 'monospace', fontWeight: 900,
          }}>⚖</div>
          <div style={{ color: AC.primary, fontSize: '18px', fontWeight: 700, letterSpacing: '0.25em' }}>JADS</div>
          <div style={{ color: AC.muted, fontSize: '10px', letterSpacing: '0.3em', marginTop: '4px' }}>FORENSIC AUDIT PORTAL</div>
          <div style={{ color: AC.primary, fontSize: '9px', letterSpacing: '0.2em', marginTop: '8px' }}>
            9-INVARIANT · SHA-256 · ECDSA P-256
          </div>
        </div>

        <form onSubmit={handleSubmit} style={{ padding: '24px 28px' }}>
          {['INVESTIGATOR ID', 'ACCESS CODE'].map((label, i) => (
            <div key={label} style={{ marginBottom: i === 0 ? '16px' : '20px' }}>
              <label style={{ display: 'block', color: AC.muted, fontSize: '10px', letterSpacing: '0.2em', marginBottom: '6px' }}>
                {label}
              </label>
              <input
                type={i === 1 ? 'password' : 'text'}
                value={i === 0 ? username : password}
                onChange={e => i === 0 ? setUsername(e.target.value) : setPassword(e.target.value)}
                placeholder={i === 0 ? 'Enter ID' : '••••••••'}
                autoComplete={i === 0 ? 'username' : 'current-password'}
                style={{
                  width: '100%', background: '#080706',
                  border: `1px solid ${AC.border}`, borderRadius: '3px',
                  padding: '10px 12px', color: AC.text,
                  fontSize: '13px', fontFamily: 'monospace', outline: 'none',
                }}
                onFocus={e => e.target.style.borderColor = AC.primary}
                onBlur={e  => e.target.style.borderColor = AC.border}
              />
            </div>
          ))}

          {error && (
            <div style={{
              background: `${AC.red}15`, border: `1px solid ${AC.red}44`,
              borderRadius: '3px', padding: '10px 12px',
              color: AC.red, fontSize: '10px', letterSpacing: '0.1em', marginBottom: '16px',
            }}>⚠ {error}</div>
          )}

          <button type="submit" disabled={loading || !username || !password} style={{
            width: '100%', padding: '12px',
            background: loading ? AC.dim : `${AC.primary}20`,
            border: `1px solid ${loading ? AC.dim : AC.primary}`,
            borderRadius: '3px',
            color: loading ? AC.muted : AC.primary,
            fontSize: '11px', fontFamily: 'monospace', fontWeight: 700,
            letterSpacing: '0.2em', cursor: loading ? 'not-allowed' : 'pointer',
            boxShadow: loading ? 'none' : `0 0 15px ${AC.primary}30`,
          }}>
            {loading ? 'AUTHENTICATING...' : 'ACCESS INVESTIGATION PORTAL →'}
          </button>
        </form>

        <div style={{
          padding: '12px 28px', borderTop: `1px solid ${AC.border}`,
          display: 'flex', justifyContent: 'space-between',
          fontSize: '9px', color: AC.muted,
        }}>
          <span>DGCA / AAI AUTHORISED</span>
          <span>JADS v4.0</span>
          <span>INDIA</span>
        </div>
      </div>
      <style>{`input::placeholder { color: #3A2A10; }`}</style>
    </div>
  )
}
