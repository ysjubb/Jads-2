// jads-audit-portal/src/App.tsx
// Full replacement — Forensic HUD theme
// Amber-dominant (investigation mode) instead of green (operations mode)

import React from 'react'
import { BrowserRouter, Routes, Route, Navigate, NavLink } from 'react-router-dom'
import { AuditLoginPage }    from './pages/AuditLoginPage'
import { MissionsPage }      from './pages/MissionsPage'
import { MissionDetailPage } from './pages/MissionDetailPage'
import { FlightPlansPage }   from './pages/FlightPlansPage'
import { ViolationsPage }    from './pages/ViolationsPage'
import { useAuditAuth }      from './hooks/useAuditAuth'

// Audit portal uses amber as primary — distinct from ops (green)
export const AC = {
  bg:      '#080706',
  surface: '#100E0A',
  border:  '#2A2010',
  primary: '#FFB800',   // amber — investigation mode
  dim:     '#6B5000',
  green:   '#00FF88',   // for PASSED verdicts
  red:     '#FF3B3B',   // for FAILED verdicts
  text:    '#F5E6C8',
  muted:   '#7A6A4A',
  scanline: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(255,184,0,0.012) 2px, rgba(255,184,0,0.012) 4px)',
}

function SideNav() {
  const { logout } = useAuditAuth()

  const navItems = [
    { to: '/missions',      label: 'DRONE MISSIONS', icon: '◎' },
    { to: '/flight-plans',  label: 'FLIGHT PLANS',   icon: '✈' },
    { to: '/violations',    label: 'VIOLATIONS',      icon: '⚠' },
  ]

  return (
    <nav style={{
      width: '200px',
      minHeight: '100vh',
      background: AC.surface,
      borderRight: `1px solid ${AC.border}`,
      display: 'flex',
      flexDirection: 'column',
      flexShrink: 0,
    }}>
      {/* Logo */}
      <div style={{
        padding: '20px 16px',
        borderBottom: `1px solid ${AC.border}`,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
          <div style={{
            width: '28px', height: '28px',
            border: `2px solid ${AC.primary}`,
            borderRadius: '4px',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: AC.primary, fontSize: '12px', fontWeight: 900,
            boxShadow: `0 0 10px ${AC.primary}44`,
            fontFamily: 'monospace',
          }}>J</div>
          <div>
            <div style={{ color: AC.primary, fontSize: '13px', fontWeight: 700, letterSpacing: '0.15em', fontFamily: 'monospace' }}>JADS</div>
            <div style={{ color: AC.muted, fontSize: '9px', letterSpacing: '0.2em' }}>AUDIT PORTAL</div>
          </div>
        </div>
        <div style={{
          background: `${AC.primary}15`,
          border: `1px solid ${AC.primary}44`,
          borderRadius: '2px',
          padding: '4px 8px',
          fontSize: '8px',
          color: AC.primary,
          letterSpacing: '0.15em',
          textAlign: 'center',
        }}>FORENSIC INVESTIGATION MODE</div>
      </div>

      {/* Nav */}
      <div style={{ flex: 1, padding: '8px 0' }}>
        {navItems.map(item => (
          <NavLink key={item.to} to={item.to} style={({ isActive }) => ({
            display: 'flex', alignItems: 'center', gap: '10px',
            padding: '10px 16px',
            textDecoration: 'none',
            color: isActive ? AC.primary : AC.muted,
            background: isActive ? `${AC.primary}10` : 'transparent',
            borderLeft: isActive ? `2px solid ${AC.primary}` : '2px solid transparent',
            fontSize: '11px', letterSpacing: '0.12em',
            fontFamily: 'monospace', fontWeight: 600,
            transition: 'all 0.15s',
          })}>
            <span style={{ fontSize: '14px' }}>{item.icon}</span>
            <span>{item.label}</span>
          </NavLink>
        ))}
      </div>

      {/* Footer */}
      <div style={{
        padding: '12px 16px',
        borderTop: `1px solid ${AC.border}`,
        fontSize: '9px', color: AC.muted, fontFamily: 'monospace',
      }}>
        <div style={{ color: AC.primary, marginBottom: '4px' }}>⚖ JUDICIAL-GRADE EVIDENCE</div>
        <div style={{ marginBottom: '2px' }}>9-INVARIANT VERIFICATION</div>
        <div>SHA-256 · ECDSA P-256</div>
        <button onClick={logout} style={{
          marginTop: '10px',
          background: 'transparent',
          border: `1px solid ${AC.border}`,
          color: AC.muted,
          padding: '4px 10px',
          borderRadius: '3px',
          cursor: 'pointer',
          fontSize: '9px',
          letterSpacing: '0.1em',
          fontFamily: 'monospace',
          width: '100%',
        }}>SIGN OUT</button>
      </div>
    </nav>
  )
}

function TopBar() {
  return (
    <div style={{
      height: '40px',
      background: AC.bg,
      borderBottom: `1px solid ${AC.border}`,
      display: 'flex', alignItems: 'center',
      padding: '0 20px', gap: '24px',
      fontFamily: 'monospace', fontSize: '10px', color: AC.muted,
      flexShrink: 0,
    }}>
      <span style={{ color: AC.primary }}>⚖ FORENSIC AUDIT COMMAND</span>
      <span style={{ marginLeft: 'auto' }}>{new Date().toUTCString().replace(' GMT', ' UTC')}</span>
    </div>
  )
}

function Protected({ children }: { children: React.ReactNode }) {
  const { token } = useAuditAuth()
  if (!token) return <Navigate to="/login" replace />

  return (
    <div style={{
      display: 'flex', minHeight: '100vh',
      background: AC.bg,
      backgroundImage: AC.scanline,
    }}>
      <SideNav />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <TopBar />
        <main style={{
          flex: 1, overflow: 'auto',
          padding: '20px',
          color: AC.text, fontFamily: 'monospace',
        }}>
          {children}
        </main>
      </div>
    </div>
  )
}

export default function App() {
  return (
    <>
      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: ${AC.bg}; color: ${AC.text}; font-family: monospace; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: ${AC.surface}; }
        ::-webkit-scrollbar-thumb { background: ${AC.dim}; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: ${AC.primary}; }
      `}</style>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<AuditLoginPage />} />
          <Route path="/*" element={
            <Protected>
              <Routes>
                <Route path="/"             element={<Navigate to="/missions" replace />} />
                <Route path="/missions"     element={<MissionsPage />} />
                <Route path="/missions/:id" element={<MissionDetailPage />} />
                <Route path="/flight-plans" element={<FlightPlansPage />} />
                <Route path="/violations"   element={<ViolationsPage />} />
              </Routes>
            </Protected>
          } />
        </Routes>
      </BrowserRouter>
    </>
  )
}
