// jads-admin-portal/src/App.tsx
// Full replacement — Military HUD theme
// Replaces the plain white nav with a dark tactical interface

import React, { useState } from 'react'
import { BrowserRouter, Routes, Route, Navigate, NavLink } from 'react-router-dom'
import { LoginPage }        from './pages/LoginPage'
import { DashboardPage }    from './pages/DashboardPage'
import { UsersPage }        from './pages/UsersPage'
import { SpecialUsersPage } from './pages/SpecialUsersPage'
import { AirspacePage }     from './pages/AirspacePage'
import { FlightPlansPage }  from './pages/FlightPlansPage'
import { DroneZonesPage }   from './pages/DroneZonesPage'
import { useAdminAuth }     from './hooks/useAdminAuth'

// ── HUD colour tokens ─────────────────────────────────────────────────────────
const C = {
  bg:       '#050A08',   // near-black with green tint
  surface:  '#0A120E',   // card backgrounds
  border:   '#1A3020',   // subtle green borders
  primary:  '#00FF88',   // primary green — active states
  dim:      '#1A6640',   // dimmed green — inactive
  amber:    '#FFB800',   // amber alerts
  red:      '#FF3B3B',   // critical alerts
  text:     '#C8E6C9',   // main text — slightly green-tinted white
  muted:    '#4A7A5A',   // secondary text
  scanline: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,255,136,0.015) 2px, rgba(0,255,136,0.015) 4px)',
}

function SideNav() {
  const { logout } = useAdminAuth()
  const [collapsed, setCollapsed] = useState(false)

  const navItems = [
    { to: '/',              label: 'OVERVIEW',      icon: '⬡' },
    { to: '/flight-plans',  label: 'FLIGHT OPS',    icon: '✈' },
    { to: '/drone-zones',   label: 'DRONE ZONES',   icon: '◎' },
    { to: '/airspace',      label: 'AIRSPACE',      icon: '▲' },
    { to: '/users',         label: 'OPERATORS',     icon: '◈' },
    { to: '/special-users', label: 'UNITS',         icon: '⬟' },
  ]

  return (
    <nav style={{
      width: collapsed ? '56px' : '200px',
      minHeight: '100vh',
      background: C.surface,
      borderRight: `1px solid ${C.border}`,
      display: 'flex',
      flexDirection: 'column',
      transition: 'width 0.2s ease',
      flexShrink: 0,
      position: 'relative',
      zIndex: 10,
    }}>
      {/* Logo block */}
      <div style={{
        padding: collapsed ? '20px 0' : '20px 16px',
        borderBottom: `1px solid ${C.border}`,
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        justifyContent: collapsed ? 'center' : 'flex-start',
      }}>
        <div style={{
          width: '28px', height: '28px',
          border: `2px solid ${C.primary}`,
          borderRadius: '4px',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: C.primary, fontSize: '12px', fontWeight: 900,
          flexShrink: 0,
          boxShadow: `0 0 10px ${C.primary}44`,
          fontFamily: 'monospace',
        }}>J</div>
        {!collapsed && (
          <div>
            <div style={{ color: C.primary, fontSize: '13px', fontWeight: 700, letterSpacing: '0.15em', fontFamily: 'monospace' }}>JADS</div>
            <div style={{ color: C.muted, fontSize: '9px', letterSpacing: '0.2em' }}>FLIGHT OPS</div>
          </div>
        )}
      </div>

      {/* Nav items */}
      <div style={{ flex: 1, padding: '8px 0' }}>
        {navItems.map(item => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/'}
            style={({ isActive }) => ({
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              padding: collapsed ? '12px 0' : '10px 16px',
              justifyContent: collapsed ? 'center' : 'flex-start',
              textDecoration: 'none',
              color: isActive ? C.primary : C.muted,
              background: isActive ? `${C.primary}10` : 'transparent',
              borderLeft: isActive ? `2px solid ${C.primary}` : '2px solid transparent',
              fontSize: '11px',
              letterSpacing: '0.12em',
              fontFamily: 'monospace',
              fontWeight: 600,
              transition: 'all 0.15s',
            })}
          >
            <span style={{ fontSize: '14px', flexShrink: 0 }}>{item.icon}</span>
            {!collapsed && <span>{item.label}</span>}
          </NavLink>
        ))}
      </div>

      {/* Status bar */}
      {!collapsed && (
        <div style={{
          padding: '12px 16px',
          borderTop: `1px solid ${C.border}`,
          fontSize: '9px',
          color: C.muted,
          fontFamily: 'monospace',
        }}>
          <div style={{ color: C.primary, marginBottom: '4px' }}>● SYSTEM ONLINE</div>
          <div>AFTN GATEWAY: STUB</div>
          <div style={{ marginTop: '8px' }}>
            <button onClick={logout} style={{
              background: 'transparent',
              border: `1px solid ${C.border}`,
              color: C.muted,
              padding: '4px 10px',
              borderRadius: '3px',
              cursor: 'pointer',
              fontSize: '9px',
              letterSpacing: '0.1em',
              fontFamily: 'monospace',
              width: '100%',
            }}>SIGN OUT</button>
          </div>
        </div>
      )}

      {/* Collapse toggle */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        style={{
          position: 'absolute',
          right: '-12px',
          top: '50%',
          transform: 'translateY(-50%)',
          background: C.surface,
          border: `1px solid ${C.border}`,
          color: C.muted,
          width: '24px',
          height: '24px',
          borderRadius: '50%',
          cursor: 'pointer',
          fontSize: '10px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 20,
        }}
      >{collapsed ? '›' : '‹'}</button>
    </nav>
  )
}

function TopBar() {
  const now = new Date()
  const utc = now.toUTCString().split(' ').slice(1,5).join(' ')

  return (
    <div style={{
      height: '40px',
      background: C.bg,
      borderBottom: `1px solid ${C.border}`,
      display: 'flex',
      alignItems: 'center',
      padding: '0 20px',
      gap: '24px',
      fontFamily: 'monospace',
      fontSize: '10px',
      color: C.muted,
      flexShrink: 0,
    }}>
      <span style={{ color: C.amber }}>⚡ JADS ADMIN COMMAND</span>
      <span style={{ marginLeft: 'auto' }}>UTC {utc}</span>
      <span style={{ color: C.primary }}>● LIVE</span>
    </div>
  )
}

function ProtectedLayout({ children }: { children: React.ReactNode }) {
  const { token } = useAdminAuth()
  if (!token) return <Navigate to="/login" replace />

  return (
    <div style={{
      display: 'flex',
      minHeight: '100vh',
      background: C.bg,
      backgroundImage: C.scanline,
    }}>
      <SideNav />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <TopBar />
        <main style={{
          flex: 1,
          overflow: 'auto',
          padding: '20px',
          color: C.text,
          fontFamily: 'monospace',
        }}>
          {children}
        </main>
      </div>
    </div>
  )
}

export default function App() {
  return (
    <>
      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: ${C.bg}; color: ${C.text}; font-family: monospace; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: ${C.surface}; }
        ::-webkit-scrollbar-thumb { background: ${C.dim}; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: ${C.primary}; }
        @keyframes pulse-green {
          0%, 100% { box-shadow: 0 0 4px #00FF8844; }
          50% { box-shadow: 0 0 12px #00FF88AA; }
        }
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.3} }
      `}</style>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/*" element={
            <ProtectedLayout>
              <Routes>
                <Route path="/"              element={<DashboardPage />} />
                <Route path="/users"         element={<UsersPage />} />
                <Route path="/special-users" element={<SpecialUsersPage />} />
                <Route path="/airspace"      element={<AirspacePage />} />
                <Route path="/drone-zones"   element={<DroneZonesPage />} />
                <Route path="/flight-plans"  element={<FlightPlansPage />} />
              </Routes>
            </ProtectedLayout>
          } />
        </Routes>
      </BrowserRouter>
    </>
  )
}
