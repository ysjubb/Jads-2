// jads-admin-portal/src/pages/LoginPage.tsx
// Full replacement — Military HUD login screen

import React, { useState, useEffect } from 'react'
import { useAdminAuth } from '../hooks/useAdminAuth'
import { useNavigate }  from 'react-router-dom'

const C = {
  bg:      '#050A08',
  surface: '#0A120E',
  border:  '#1A3020',
  primary: '#00FF88',
  dim:     '#1A6640',
  amber:   '#FFB800',
  red:     '#FF3B3B',
  text:    '#C8E6C9',
  muted:   '#4A7A5A',
}

export function LoginPage() {
  const { login, token } = useAdminAuth()
  const navigate = useNavigate()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError]       = useState('')
  const [loading, setLoading]   = useState(false)
  const [tick, setTick]         = useState(0)

  useEffect(() => {
    if (token) navigate('/', { replace: true })
  }, [token])

  useEffect(() => {
    const t = setInterval(() => setTick(n => n + 1), 1000)
    return () => clearInterval(t)
  }, [])

  const utcTime = new Date().toUTCString().replace('GMT', 'UTC')

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      await login(username.trim(), password)
      navigate('/', { replace: true })
    } catch {
      setError('AUTHENTICATION FAILED — CHECK CREDENTIALS')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: C.bg,
      backgroundImage: `
        radial-gradient(ellipse at 20% 50%, #001A0E 0%, transparent 60%),
        radial-gradient(ellipse at 80% 20%, #001408 0%, transparent 50%),
        repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,255,136,0.012) 2px, rgba(0,255,136,0.012) 4px)
      `,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'monospace',
      padding: '20px',
    }}>
      {/* Corner decorations */}
      {[
        { top: '20px', left: '20px', borderTop: `2px solid ${C.dim}`, borderLeft: `2px solid ${C.dim}` },
        { top: '20px', right: '20px', borderTop: `2px solid ${C.dim}`, borderRight: `2px solid ${C.dim}` },
        { bottom: '20px', left: '20px', borderBottom: `2px solid ${C.dim}`, borderLeft: `2px solid ${C.dim}` },
        { bottom: '20px', right: '20px', borderBottom: `2px solid ${C.dim}`, borderRight: `2px solid ${C.dim}` },
      ].map((s, i) => (
        <div key={i} style={{ position: 'fixed', width: '40px', height: '40px', ...s }} />
      ))}

      {/* Status bar top */}
      <div style={{
        position: 'fixed', top: 0, left: 0, right: 0,
        padding: '8px 20px',
        borderBottom: `1px solid ${C.border}`,
        display: 'flex', justifyContent: 'space-between',
        fontSize: '10px', color: C.muted,
        background: `${C.surface}CC`,
      }}>
        <span style={{ color: C.amber }}>⚡ JADS SECURE ACCESS TERMINAL</span>
        <span>{utcTime}</span>
        <span style={{ color: C.primary }}>● SYSTEM READY</span>
      </div>

      {/* Main card */}
      <div style={{
        width: '100%', maxWidth: '400px',
        background: C.surface,
        border: `1px solid ${C.border}`,
        borderRadius: '4px',
        overflow: 'hidden',
        boxShadow: `0 0 60px ${C.primary}15, 0 0 120px ${C.primary}08`,
      }}>
        {/* Card header */}
        <div style={{
          padding: '24px 28px 20px',
          borderBottom: `1px solid ${C.border}`,
          textAlign: 'center',
        }}>
          <div style={{
            width: '56px', height: '56px',
            border: `2px solid ${C.primary}`,
            borderRadius: '6px',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 16px',
            color: C.primary, fontSize: '22px', fontWeight: 900,
            boxShadow: `0 0 20px ${C.primary}44`,
            animation: 'pulse-green 3s ease-in-out infinite',
          }}>J</div>
          <div style={{ color: C.primary, fontSize: '18px', fontWeight: 700, letterSpacing: '0.25em' }}>JADS</div>
          <div style={{ color: C.muted, fontSize: '10px', letterSpacing: '0.3em', marginTop: '4px' }}>
            JOINT AIRSPACE DRONE SYSTEM
          </div>
          <div style={{ color: C.amber, fontSize: '9px', letterSpacing: '0.2em', marginTop: '8px' }}>
            FLIGHT OPERATIONS COMMAND
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} style={{ padding: '24px 28px' }}>
          <div style={{ marginBottom: '16px' }}>
            <label style={{ display: 'block', color: C.muted, fontSize: '10px', letterSpacing: '0.2em', marginBottom: '6px' }}>
              OPERATOR ID
            </label>
            <input
              value={username}
              onChange={e => setUsername(e.target.value)}
              placeholder="Enter ID"
              autoComplete="username"
              style={{
                width: '100%',
                background: '#050A08',
                border: `1px solid ${C.border}`,
                borderRadius: '3px',
                padding: '10px 12px',
                color: C.text,
                fontSize: '13px',
                fontFamily: 'monospace',
                outline: 'none',
              }}
              onFocus={e => e.target.style.borderColor = C.primary}
              onBlur={e  => e.target.style.borderColor = C.border}
            />
          </div>

          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', color: C.muted, fontSize: '10px', letterSpacing: '0.2em', marginBottom: '6px' }}>
              ACCESS CODE
            </label>
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="••••••••"
              autoComplete="current-password"
              style={{
                width: '100%',
                background: '#050A08',
                border: `1px solid ${C.border}`,
                borderRadius: '3px',
                padding: '10px 12px',
                color: C.text,
                fontSize: '13px',
                fontFamily: 'monospace',
                outline: 'none',
              }}
              onFocus={e => e.target.style.borderColor = C.primary}
              onBlur={e  => e.target.style.borderColor = C.border}
            />
          </div>

          {error && (
            <div style={{
              background: `${C.red}15`,
              border: `1px solid ${C.red}44`,
              borderRadius: '3px',
              padding: '10px 12px',
              color: C.red,
              fontSize: '10px',
              letterSpacing: '0.1em',
              marginBottom: '16px',
            }}>⚠ {error}</div>
          )}

          <button
            type="submit"
            disabled={loading || !username || !password}
            style={{
              width: '100%',
              padding: '12px',
              background: loading ? C.dim : `${C.primary}20`,
              border: `1px solid ${loading ? C.dim : C.primary}`,
              borderRadius: '3px',
              color: loading ? C.muted : C.primary,
              fontSize: '11px',
              fontFamily: 'monospace',
              fontWeight: 700,
              letterSpacing: '0.2em',
              cursor: loading ? 'not-allowed' : 'pointer',
              transition: 'all 0.2s',
              boxShadow: loading ? 'none' : `0 0 15px ${C.primary}30`,
            }}
          >
            {loading ? 'AUTHENTICATING...' : 'AUTHENTICATE →'}
          </button>
        </form>

        {/* Footer */}
        <div style={{
          padding: '12px 28px',
          borderTop: `1px solid ${C.border}`,
          display: 'flex', justifyContent: 'space-between',
          fontSize: '9px', color: C.muted,
        }}>
          <span>TRL-6 PLATFORM</span>
          <span>JADS v4.0</span>
          <span>INDIA</span>
        </div>
      </div>

      <style>{`
        @keyframes pulse-green {
          0%,100% { box-shadow: 0 0 20px #00FF8844; }
          50%      { box-shadow: 0 0 35px #00FF88AA; }
        }
        input::placeholder { color: #2A4A34; }
      `}</style>
    </div>
  )
}
