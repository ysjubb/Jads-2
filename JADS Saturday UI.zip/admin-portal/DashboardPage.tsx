// jads-admin-portal/src/pages/DashboardPage.tsx
// Full replacement — Military HUD dashboard

import React, { useEffect, useState } from 'react'
import { useAdminAuth, adminAxios } from '../hooks/useAdminAuth'
import { useNavigate } from 'react-router-dom'

const C = {
  bg: '#050A08', surface: '#0A120E', border: '#1A3020',
  primary: '#00FF88', dim: '#1A6640', amber: '#FFB800',
  red: '#FF3B3B', text: '#C8E6C9', muted: '#4A7A5A',
}

interface Stats {
  civilianUsers: number; specialUsers: number
  pendingVersions: number; suspendedUsers: number; dueReconfirmation: number
}

function HudStat({ label, value, color, sub, onClick }: {
  label: string; value: number | string; color: string; sub?: string; onClick?: () => void
}) {
  return (
    <div onClick={onClick} style={{
      background: C.surface,
      border: `1px solid ${C.border}`,
      borderTop: `2px solid ${color}`,
      padding: '20px',
      cursor: onClick ? 'pointer' : 'default',
      flex: '1 1 160px',
      minWidth: '150px',
      position: 'relative',
      overflow: 'hidden',
      transition: 'border-color 0.2s',
    }}
    onMouseEnter={e => onClick && (e.currentTarget.style.borderColor = color)}
    onMouseLeave={e => onClick && (e.currentTarget.style.borderColor = C.border)}
    >
      {/* Background glow */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0,
        height: '60px',
        background: `linear-gradient(180deg, ${color}10 0%, transparent 100%)`,
        pointerEvents: 'none',
      }} />
      <div style={{ color, fontSize: '32px', fontWeight: 900, fontFamily: 'monospace', lineHeight: 1 }}>
        {value}
      </div>
      <div style={{ color: C.muted, fontSize: '10px', letterSpacing: '0.2em', marginTop: '8px' }}>
        {label}
      </div>
      {sub && <div style={{ color, fontSize: '9px', marginTop: '4px' }}>{sub}</div>}
    </div>
  )
}

function RadarRing() {
  return (
    <svg width="160" height="160" style={{ opacity: 0.15 }}>
      <circle cx="80" cy="80" r="70" stroke="#00FF88" strokeWidth="0.5" fill="none"/>
      <circle cx="80" cy="80" r="50" stroke="#00FF88" strokeWidth="0.5" fill="none"/>
      <circle cx="80" cy="80" r="30" stroke="#00FF88" strokeWidth="0.5" fill="none"/>
      <line x1="80" y1="10" x2="80" y2="150" stroke="#00FF88" strokeWidth="0.5"/>
      <line x1="10" y1="80" x2="150" y2="80" stroke="#00FF88" strokeWidth="0.5"/>
      <line x1="30" y1="30" x2="130" y2="130" stroke="#00FF88" strokeWidth="0.3"/>
      <line x1="130" y1="30" x2="30" y2="130" stroke="#00FF88" strokeWidth="0.3"/>
    </svg>
  )
}

function ActivityRow({ label, value, total, color }: { label: string; value: number; total: number; color: string }) {
  const pct = total > 0 ? Math.round((value / total) * 100) : 0
  return (
    <div style={{ marginBottom: '12px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
        <span style={{ fontSize: '10px', color: C.muted, letterSpacing: '0.1em' }}>{label}</span>
        <span style={{ fontSize: '10px', color, fontFamily: 'monospace' }}>{value} / {total}</span>
      </div>
      <div style={{ height: '4px', background: C.border, borderRadius: '2px' }}>
        <div style={{
          height: '100%', width: `${pct}%`,
          background: color, borderRadius: '2px',
          boxShadow: `0 0 6px ${color}`,
          transition: 'width 0.8s ease',
        }} />
      </div>
    </div>
  )
}

export function DashboardPage() {
  const { token, logout } = useAdminAuth()
  const navigate = useNavigate()
  const [stats, setStats]     = useState<Stats | null>(null)
  const [loading, setLoading] = useState(false)
  const [time, setTime]       = useState(new Date())

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000)
    return () => clearInterval(t)
  }, [])

  useEffect(() => {
    if (!token) return
    setLoading(true)
    adminAxios(token).get('/admin/dashboard')
      .then(r => setStats(r.data))
      .catch(logout)
      .finally(() => setLoading(false))
  }, [token])

  const total = stats ? stats.civilianUsers + stats.specialUsers : 0
  const utc   = time.toUTCString().replace(' GMT','')

  return (
    <div style={{ fontFamily: 'monospace', color: C.text }}>

      {/* Page header */}
      <div style={{ marginBottom: '24px', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <div>
          <div style={{ color: C.primary, fontSize: '11px', letterSpacing: '0.3em', marginBottom: '4px' }}>
            ▸ COMMAND OVERVIEW
          </div>
          <div style={{ color: C.text, fontSize: '22px', fontWeight: 700, letterSpacing: '0.1em' }}>
            AIRSPACE STATUS
          </div>
        </div>
        <div style={{ textAlign: 'right', fontSize: '10px', color: C.muted }}>
          <div style={{ color: C.primary, marginBottom: '2px' }}>● LIVE</div>
          <div>{utc}</div>
        </div>
      </div>

      {/* Stat row */}
      <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', marginBottom: '24px' }}>
        <HudStat label="CIVILIAN OPS" value={stats?.civilianUsers ?? '—'} color={C.primary}
          onClick={() => navigate('/users')} sub="↗ ACTIVE OPERATORS" />
        <HudStat label="SPECIAL UNITS" value={stats?.specialUsers ?? '—'} color={C.amber}
          onClick={() => navigate('/special-users')} sub="↗ AUTHORISED" />
        <HudStat label="PENDING REVIEW" value={stats?.pendingVersions ?? '—'}
          color={stats?.pendingVersions ? C.amber : C.dim} />
        <HudStat label="SUSPENDED" value={stats?.suspendedUsers ?? '—'}
          color={stats?.suspendedUsers ? C.red : C.dim} />
        <HudStat label="DUE RECONFIRM" value={stats?.dueReconfirmation ?? '—'}
          color={stats?.dueReconfirmation ? C.amber : C.dim} />
      </div>

      {/* Middle row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px', marginBottom: '24px' }}>

        {/* Operator breakdown */}
        <div style={{ background: C.surface, border: `1px solid ${C.border}`, padding: '20px', gridColumn: 'span 2' }}>
          <div style={{ color: C.muted, fontSize: '10px', letterSpacing: '0.2em', marginBottom: '16px' }}>
            ▸ OPERATOR DISTRIBUTION
          </div>
          <ActivityRow label="CIVILIAN OPERATORS" value={stats?.civilianUsers ?? 0} total={total || 1} color={C.primary} />
          <ActivityRow label="SPECIAL / UNIT ACCOUNTS" value={stats?.specialUsers ?? 0} total={total || 1} color={C.amber} />
          <ActivityRow label="SUSPENDED ACCOUNTS" value={stats?.suspendedUsers ?? 0} total={total || 1} color={C.red} />
          <ActivityRow label="PENDING RECONFIRMATION" value={stats?.dueReconfirmation ?? 0} total={total || 1} color="#7B8CDE" />
        </div>

        {/* Radar decoration */}
        <div style={{
          background: C.surface, border: `1px solid ${C.border}`,
          display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center',
          padding: '20px', position: 'relative',
        }}>
          <RadarRing />
          <div style={{
            position: 'absolute',
            textAlign: 'center',
          }}>
            <div style={{ color: C.primary, fontSize: '20px', fontWeight: 900 }}>{total}</div>
            <div style={{ color: C.muted, fontSize: '9px', letterSpacing: '0.15em' }}>TOTAL OPS</div>
          </div>
        </div>
      </div>

      {/* System status */}
      <div style={{ background: C.surface, border: `1px solid ${C.border}`, padding: '20px' }}>
        <div style={{ color: C.muted, fontSize: '10px', letterSpacing: '0.2em', marginBottom: '16px' }}>
          ▸ SYSTEM STATUS
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '12px' }}>
          {[
            { label: 'AFTN GATEWAY',     status: 'STUB — NOT LIVE',  color: C.amber },
            { label: 'NOTAM ADAPTER',    status: 'STUB — NOT LIVE',  color: C.amber },
            { label: 'METAR ADAPTER',    status: 'STUB — NOT LIVE',  color: C.amber },
            { label: 'FORENSIC ENGINE',  status: 'ONLINE',           color: C.primary },
            { label: 'HASH CHAIN',       status: 'ONLINE',           color: C.primary },
            { label: 'ADC/FIC TRACKING', status: 'ONLINE',           color: C.primary },
            { label: 'NPNT GATE',        status: 'ONLINE — ANDROID', color: C.primary },
            { label: 'AI AGENTS',        status: 'LOCALHOST:3101-04', color: '#7B8CDE' },
          ].map(s => (
            <div key={s.label} style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '8px 12px',
              background: '#050A08',
              border: `1px solid ${C.border}`,
              borderRadius: '2px',
            }}>
              <span style={{ fontSize: '9px', color: C.muted, letterSpacing: '0.1em' }}>{s.label}</span>
              <span style={{ fontSize: '9px', color: s.color }}>{s.status}</span>
            </div>
          ))}
        </div>
      </div>

      {loading && (
        <div style={{
          position: 'fixed', bottom: '20px', right: '20px',
          color: C.muted, fontSize: '10px',
          animation: 'blink 1s step-end infinite',
        }}>LOADING...</div>
      )}

      <style>{`
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }
      `}</style>
    </div>
  )
}
