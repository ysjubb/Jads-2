package com.jads.drone

import com.jads.crypto.EcdsaSigner
import com.jads.crypto.HashChainEngine
import com.jads.storage.SqlCipherMissionStore
import com.jads.telemetry.CanonicalSerializer
import com.jads.telemetry.TelemetryFields
import com.jads.time.MonotonicClock
import com.jads.time.NtpQuorumAuthority
import com.jads.time.SyncStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// MissionController — orchestrates the full drone mission lifecycle.
//
// Start order (MUST be respected):
//   1. NpntComplianceGate.evaluate()    — if RED, HARD STOP. No exceptions.
//   2. NtpQuorumAuthority.sync()        — if FAILED, block mission
//   3. CertificateValidator.validate()  — if invalid, block mission
//   4. Generate missionId + HASH_0
//   5. SqlCipherMissionStore.createMission()
//
// Record order (per sensor tick):
//   1. GnssPlausibilityValidator.validate()  — set health flags, never drop records
//   2. MonotonicClock.nextTimestamp()         — NTP-corrected, never System.currentTimeMillis()
//   3. CanonicalSerializer.serialize()        — 96-byte canonical payload
//   4. EcdsaSigner.sha256() + sign()          — ECDSA over the 96 bytes
//   5. HashChainEngine.computeHashN()         — forensic chain link
//   6. SqlCipherMissionStore.saveRecord()
//   7. LandingDetector.processSample()        — trigger finalize on landing

sealed class MissionStartResult {
    data class Started(val missionDbId: Long, val missionId: Long) : MissionStartResult()
    data class Blocked(val reason: String, val details: List<String>) : MissionStartResult()
}

data class RawSensorFields(
    val latDeg:         Double,
    val lonDeg:         Double,
    val altMeters:      Double,
    val hdop:           Float,
    val satelliteCount: Int,
    val velNorthMs:     Double,   // m/s — converted to mm/s internally
    val velEastMs:      Double,
    val velDownMs:      Double,
    val flightState:    Int       // bitmask
)

class MissionController(
    private val npntGate:       NpntComplianceGate,
    private val ntpAuthority:   NtpQuorumAuthority,
    private val store:          SqlCipherMissionStore,
    private val clock:          MonotonicClock,
    private val privateKeyBytes: ByteArray,
    private val onMissionFinalized: suspend (missionDbId: Long) -> Unit
) {
    private var missionDbId:     Long     = -1L
    private var missionId:       Long     = -1L
    private var currentSequence: Long     = 0L
    private var currentHash:     ByteArray = ByteArray(32)
    private var prevGnss:        GnssPlausibilityValidator.GnssReading? = null
    private val landingDetector  = LandingDetector()
    private var active           = false

    // ── START ───────────────────────────────────────────────────────────────

    suspend fun startMission(
        latDeg:           Double,
        lonDeg:           Double,
        plannedAglFt:     Double,
        permissionToken:  String?,
        idempotencyKey:   String,
        deviceCertHash:   String,
        // Device attestation — provided by Android KeyStore attestation flow
        strongboxBacked:  Boolean = false,
        secureBootVerified: Boolean = false,
        androidVersion:   Int = 0
    ): MissionStartResult = withContext(Dispatchers.IO) {

        // Step 1: NPNT gate — MUST be first
        val npnt = npntGate.evaluate(latDeg, lonDeg, plannedAglFt, permissionToken)
        if (npnt.blocked) {
            return@withContext MissionStartResult.Blocked(
                "NPNT_BLOCKED", npnt.blockingReasons
            )
        }

        // StrongBox degradation warning — logged but does NOT block mission.
        // JADS records whether hardware security was available at mission start.
        // Degradation means the key is software-backed (less tamper-resistant).
        if (!strongboxBacked) {
            // LOG: key will be software-backed this mission
            // Server receives this flag and records it in device_attestation
        }

        // Step 2: NTP quorum
        val ntpEvidence = ntpAuthority.syncAndGetEvidence()
        if (ntpEvidence.syncStatus == SyncStatus.FAILED) {
            return@withContext MissionStartResult.Blocked(
                "NTP_QUORUM_FAILED",
                listOf("NTP quorum not reached. Mission requires at least 2 time servers.")
            )
        }
        clock.updateCorrection(ntpEvidence.correctionMs)

        // Step 3: (Certificate validation would be injected — skipped for stub)

        // Step 4: Generate missionId and HASH_0
        val id      = System.currentTimeMillis()
        val hash0   = HashChainEngine.computeHash0(id)
        val rootHex = HashChainEngine.toHex(hash0)

        // Step 5: Persist mission record (includes attestation metadata)
        val ntpJson = buildNtpJson(ntpEvidence)
        val dbId = store.createMission(
            missionId            = id,
            npntClassification   = npnt.classification.name,
            npntPermissionToken  = npnt.permissionToken,
            deviceCertHash       = deviceCertHash,
            rootHashHex          = rootHex,
            ntpEvidenceJson      = ntpJson,
            idempotencyKey       = idempotencyKey,
            startUtcMs           = clock.nextTimestamp(),
            strongboxBacked      = strongboxBacked,
            secureBootVerified   = secureBootVerified,
            androidVersion       = androidVersion
        )

        missionDbId     = dbId
        missionId       = id
        currentSequence = 0L
        currentHash     = hash0
        prevGnss        = null
        landingDetector.reset()
        active          = true

        MissionStartResult.Started(dbId, id)
    }

    // ── RECORD ───────────────────────────────────────────────────────────────

    suspend fun processReading(raw: RawSensorFields) = withContext(Dispatchers.IO) {
        if (!active) return@withContext

        // Step 1: GNSS plausibility — set health flags, NEVER drop records
        val gnssReading = GnssPlausibilityValidator.GnssReading(
            hdop           = raw.hdop,
            satelliteCount = raw.satelliteCount,
            latDeg         = raw.latDeg,
            lonDeg         = raw.lonDeg,
            altMeters      = raw.altMeters
        )
        val gnssResult    = GnssPlausibilityValidator.validate(gnssReading, prevGnss)
        val sensorFlags   = GnssPlausibilityValidator.applySensorFlags(gnssResult, 0)
        prevGnss          = gnssReading

        // Step 2: Normalize values
        val latMicrodeg  = (raw.latDeg  * 1_000_000.0).toLong()
        val lonMicrodeg  = (raw.lonDeg  * 1_000_000.0).toLong()
        val altCm        = (raw.altMeters * 100.0).toLong()
        val velNorthMms  = (raw.velNorthMs * 1000.0).toLong()
        val velEastMms   = (raw.velEastMs  * 1000.0).toLong()
        val velDownMms   = (raw.velDownMs  * 1000.0).toLong()

        // Step 3: NTP-corrected monotonic timestamp — never System.currentTimeMillis()
        val timestamp = clock.nextTimestamp()

        // Step 4: Prev hash prefix (first 8 bytes of current chain hash)
        val prevHashPrefix = currentHash.copyOf(8)

        // Step 5: Build and serialize canonical payload
        val fields = TelemetryFields(
            missionId         = missionId,
            recordSequence    = currentSequence,
            timestampUtcMs    = timestamp,
            latitudeMicrodeg  = latMicrodeg,
            longitudeMicrodeg = lonMicrodeg,
            altitudeCm        = altCm,
            velocityNorthMms  = velNorthMms,
            velocityEastMms   = velEastMms,
            velocityDownMms   = velDownMms,
            prevHashPrefix    = prevHashPrefix,
            flightStateFlags  = raw.flightState,
            sensorHealthFlags = sensorFlags
        )
        val canonical96 = CanonicalSerializer.serialize(fields)

        // Step 6: Sign
        val hash32       = EcdsaSigner.sha256(canonical96)
        val signatureDer = EcdsaSigner.sign(hash32, privateKeyBytes)

        // Step 7: Advance hash chain
        val newHash = HashChainEngine.computeHashN(canonical96, currentHash)

        // Step 8: Persist
        store.saveRecord(
            missionDbId  = missionDbId,
            missionId    = missionId,
            sequence     = currentSequence,
            canonicalHex = HashChainEngine.toHex(canonical96),
            signatureHex = HashChainEngine.toHex(signatureDer),
            hashHex      = HashChainEngine.toHex(newHash),
            prevHashHex  = HashChainEngine.toHex(currentHash),
            timestampMs  = timestamp
        )

        // Step 9: Detect violations
        checkViolations(raw, latMicrodeg, lonMicrodeg, altCm, timestamp)

        // Advance state
        currentHash     = newHash
        currentSequence += 1

        // Step 10: Landing detection
        val snapshot = LandingDetector.SensorSnapshot(
            altitudeCm       = altCm,
            velocityNorthMms = velNorthMms,
            velocityEastMms  = velEastMms,
            velocityDownMms  = velDownMms
        )
        if (landingDetector.processSample(snapshot)) {
            active = false
            finalizeMission()
        }
    }

    // ── RESUME ───────────────────────────────────────────────────────────────

    fun resumeMission(existingMissionId: Long) {
        // CRITICAL: read lastStoredSequence from SQLCipher and continue from +1.
        // Never restart from 0. A sequence gap triggers chain verification failure.
        //
        // existingMissionId is the missionId (timestamp Long), NOT the Room primary key.
        // We must look up the MissionEntity to get the Room db id (missionDbId).
        val entity = store.getMissionByMissionId(existingMissionId)
        if (entity == null) {
            // Mission not found in local DB — cannot resume
            return
        }

        missionDbId     = entity.id               // Room primary key — used for all DAO calls
        missionId       = existingMissionId
        val lastSeq     = store.getLastSequence(existingMissionId)
        currentSequence = lastSeq + 1             // resume from next sequence number
        active          = true

        // Re-establish currentHash from the last stored record's hash.
        // If we start from ByteArray(32), the hash chain breaks from the first new record.
        val records = store.getRecords(missionDbId)
        currentHash = if (records.isNotEmpty()) {
            HashChainEngine.fromHex(records.last().recordHashHex)
        } else {
            // No records yet — this is a fresh mission that was interrupted at startMission.
            // Recompute HASH_0 from missionId.
            HashChainEngine.computeHash0(missionId)
        }
    }

    // ── FINALIZE ────────────────────────────────────────────────────────────

    private suspend fun finalizeMission() {
        // Post-flight upload only after:
        // (1) Landing confirmed — already done (LandingDetector fired)
        // (2) Local integrity check
        val integrityOk = runLocalIntegrityCheck()
        store.setIntegrityCheckResult(missionDbId, integrityOk)

        // (3) CRL revalidation — result stored regardless of outcome
        val archivedCrl = revalidateCertAndGetCrl()
        store.finalizeMission(missionDbId, archivedCrl, clock.nextTimestamp())

        // Trigger upload callback
        onMissionFinalized(missionDbId)
    }

    private fun runLocalIntegrityCheck(): Boolean {
        val records = store.getRecords(missionDbId)
        if (records.isEmpty()) return true
        // Verify sequence is gapless
        for (i in records.indices) {
            if (records[i].sequence != i.toLong()) return false
        }
        return true
    }

    private fun revalidateCertAndGetCrl(): String? {
        // Stub — live implementation calls CertificateValidator.revalidate()
        // which fetches fresh CRL bytes from the CA and returns them as base64.
        // The CRL is archived here, not on backend — frozen at mission_end_utc.
        return null
    }

    private fun checkViolations(
        raw:         RawSensorFields,
        latMicrodeg: Long, lonMicrodeg: Long, altCm: Long, timestamp: Long
    ) {
        val altFt = raw.altMeters * 3.28084
        if (altFt > 400.0) {
            store.saveViolation(
                missionDbId   = missionDbId,
                missionId     = missionId,
                sequence      = currentSequence,
                violationType = "AGL_EXCEEDED",
                severity      = "CRITICAL",
                timestampMs   = timestamp,
                latMicrodeg   = latMicrodeg,
                lonMicrodeg   = lonMicrodeg,
                altCm         = altCm,
                detailJson    = """{"limitFt":400,"actualFt":$altFt}"""
            )
        }
    }

    private fun buildNtpJson(ev: com.jads.time.TimeAuthorityEvidence): String =
        """{"syncStatus":"${ev.syncStatus}","correctionMs":${ev.correctionMs},"spreadMs":${ev.spreadMs},"servers":${ev.servers},"evidenceTimeMs":${ev.evidenceTimeMs}}"""
}
