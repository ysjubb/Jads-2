// ─────────────────────────────────────────────────────────────────────────────
// JADS AI Agent 3 — AFTN Draft Builder
// File: jads-agents/aftn-draft/index.ts
//
// What it does:
//   Takes a natural language instruction and produces a DRAFT AFTN message
//   (CNL or DLA) for human review before sending.
//
//   Example input:  "Cancel the VIDP to VOMM flight for VT-ABC, crew unavailable"
//   Example output: Draft CNL message + structured fields for UI display
//
// ARR is intentionally NOT implemented:
//   Arrival confirmation requires real-time ATC monitoring — outside this
//   platform's scope. See architecture decision in CLAUDE.md.
//
// Critical rule — DRAFT ONLY:
//   This agent produces drafts. A human MUST review and approve before the
//   message is sent via AftnGateway. The agent never calls the gateway directly.
//   The approve endpoint in the backend calls the gateway — not this agent.
//
// Supported message types: CNL (cancel) and DLA (delay)
//
// Runs on: Ollama local (llama3.1:8b-instruct-q4_K_M) — 8GB RAM compatible
// Port: 3103
// ─────────────────────────────────────────────────────────────────────────────

import express from 'express'
import { createServiceLogger } from './logger'

const app = express()
app.use(express.json())
const log = createServiceLogger('AftnDraftBuilder')

const OLLAMA_URL = process.env.OLLAMA_URL ?? 'http://localhost:11434'
const MODEL      = process.env.DRAFT_MODEL ?? 'llama3.1:8b-instruct-q4_K_M'
const PORT       = parseInt(process.env.PORT ?? '3103')

// ── System prompt ─────────────────────────────────────────────────────────────
const SYSTEM_PROMPT = `You are an AFTN message assistant for JADS aviation platform.
You extract the fields needed to build a CNL (cancel) or DLA (delay) AFTN message from natural language instructions.

Return ONLY valid JSON with no markdown, no explanation. Schema:
{
  "messageType": "CNL" or "DLA" — determine from the instruction,
  "callsign": "string — aircraft/flight callsign, uppercase, no spaces",
  "departureIcao": "4-letter ICAO code, uppercase",
  "destination": "4-letter ICAO code, uppercase",
  "originalEobt": "DDHHmm string if determinable, else null",
  "newEobt": "DDHHmm string for DLA only, else null",
  "reason": "brief plain English reason, max 60 chars, uppercase, or null",
  "confidence": "HIGH | MEDIUM | LOW — how confident you are in the extraction",
  "missingFields": ["list of field names that could not be determined"]
}

If the instruction does not clearly indicate CNL or DLA, set messageType to null.
If a required field cannot be determined, include it in missingFields.
ICAO codes are always 4 letters — convert common names: Delhi=VIDP, Mumbai=VABB, Bangalore=VOBL, Chennai=VOMM, Hyderabad=VOHS, Kolkata=VECC.
EOBT format is DDHHmm — Day(2) + Hour(2) + Minute(2) UTC. Example: 15 Oct 14:30 UTC = 151430.`

// ── Interfaces ────────────────────────────────────────────────────────────────
interface AftnDraftRequest {
  instruction:   string   // Natural language — e.g. "cancel VT-ABC VIDP to VOMM, crew rest"
  flightPlanId?: string   // Optional — if provided, backend can auto-fill missing fields
  // Pre-populated fields (from the flight plan record, if known)
  // The agent fills gaps; these override agent output if provided
  callsign?:       string
  departureIcao?:  string
  destination?:    string
  originalEobt?:   string
}

interface AftnDraftResult {
  messageType:   'CNL' | 'DLA' | null
  callsign:      string | null
  departureIcao: string | null
  destination:   string | null
  originalEobt:  string | null
  newEobt:       string | null
  reason:        string | null
  confidence:    'HIGH' | 'MEDIUM' | 'LOW'
  missingFields: string[]
  // Preview of the message body — for display in the UI before approval
  // Built from extracted fields using the deterministic builders
  // null if required fields are missing
  draftMessagePreview: string | null
  _agentModel:         string
  _agentLatencyMs:     number
}

// ── Main draft endpoint ───────────────────────────────────────────────────────
app.post('/draft', async (req, res) => {
  const start = Date.now()
  const input = req.body as AftnDraftRequest

  if (!input.instruction || input.instruction.trim().length < 5) {
    res.status(400).json({ error: 'INSTRUCTION_REQUIRED' })
    return
  }

  const userPrompt = `Extract AFTN message fields from this instruction:\n"${input.instruction}"`

  try {
    const ollamaRes = await fetch(`${OLLAMA_URL}/api/chat`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model:  MODEL,
        stream: false,
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          { role: 'user',   content: userPrompt   },
        ],
        options: { temperature: 0, num_predict: 256 }
      })
    })

    if (!ollamaRes.ok) {
      throw new Error(`Ollama returned ${ollamaRes.status}`)
    }

    const ollamaData = await ollamaRes.json() as { message: { content: string } }
    const rawText    = ollamaData.message.content.trim()
    const latencyMs  = Date.now() - start

    let parsed: Record<string, unknown> = {}
    try {
      const cleaned = rawText.replace(/^```json\s*/i, '').replace(/```\s*$/i, '').trim()
      parsed = JSON.parse(cleaned)
    } catch {
      log.warn('draft_parse_failed', { data: { rawText: rawText.substring(0, 200) } })
    }

    // Merge — caller-supplied fields override agent extraction
    // This means if the UI already has the callsign from the flight plan record,
    // it passes it in and the agent doesn't need to guess it
    const callsign      = input.callsign      ?? (parsed.callsign      as string | null) ?? null
    const departureIcao = input.departureIcao ?? (parsed.departureIcao as string | null) ?? null
    const destination   = input.destination   ?? (parsed.destination   as string | null) ?? null
    const originalEobt  = input.originalEobt  ?? (parsed.originalEobt  as string | null) ?? null
    const newEobt       =                         (parsed.newEobt       as string | null) ?? null
    const messageType   =                         (parsed.messageType   as 'CNL' | 'DLA' | null) ?? null
    const reason        =                         (parsed.reason        as string | null) ?? null
    const confidence    =                         (parsed.confidence    as 'HIGH' | 'MEDIUM' | 'LOW') ?? 'LOW'
    const missingFields =                         (parsed.missingFields as string[]) ?? []

    // Build a preview message using the deterministic builders
    // This lets the UI show exactly what will be sent — before human approval
    let draftMessagePreview: string | null = null

    if (messageType === 'CNL' && callsign && departureIcao && destination && originalEobt) {
      draftMessagePreview = `(CNL-${callsign}-${departureIcao}-${originalEobt}-${destination}-${reason ? `0/RMK/${reason} ` : ''})`
    } else if (messageType === 'DLA' && callsign && departureIcao && destination && originalEobt && newEobt) {
      draftMessagePreview = `(DLA-${callsign}-${departureIcao}-${originalEobt}-${destination}-${newEobt}-${reason ? `0/RMK/${reason} ` : ''})`
    }

    log.info('draft_built', {
      data: {
        messageType,
        confidence,
        missingFields,
        hasPreview: !!draftMessagePreview,
        latencyMs,
      }
    })

    const result: AftnDraftResult = {
      messageType,
      callsign,
      departureIcao,
      destination,
      originalEobt,
      newEobt,
      reason,
      confidence,
      missingFields,
      draftMessagePreview,
      _agentModel:     MODEL,
      _agentLatencyMs: latencyMs,
    }

    res.json({ success: true, result })

  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : String(e)
    log.error('draft_build_error', { data: { error: msg } })
    res.status(502).json({ error: 'OLLAMA_CALL_FAILED', detail: msg })
  }
})

// ── Health check ─────────────────────────────────────────────────────────────
app.get('/health', async (_req, res) => {
  try {
    const r = await fetch(`${OLLAMA_URL}/api/tags`)
    res.json({ status: r.ok ? 'ok' : 'ollama_unreachable', model: MODEL, port: PORT })
  } catch {
    res.status(503).json({ status: 'ollama_unreachable', model: MODEL })
  }
})

app.listen(PORT, () => {
  log.info('aftn_draft_builder_started', { data: { port: PORT, model: MODEL } })
})

export default app
