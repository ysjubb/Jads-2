// ─────────────────────────────────────────────────────────────────────────────
// JADS AI Agent 4 — Flight Plan Anomaly Advisor
// File: jads-agents/anomaly-advisor/index.ts
//
// What it does:
//   Reviews a newly filed flight plan against context (recent operator history,
//   active NOTAMs, time of day, route) and surfaces advisory flags to the
//   approving officer in the admin portal.
//
// Critical rules:
//   1. This agent NEVER blocks a flight plan. It produces advisories only.
//   2. The approving officer sees the flags and makes the decision.
//   3. Flags are labelled ADVISORY — never BLOCK, REJECT, or DENY.
//   4. The agent does not have access to classified or restricted data.
//
// Examples of what it flags:
//   - Flight plan filed at 02:00 UTC for immediate departure
//   - Same operator filed 4 plans in 6 hours to different destinations
//   - Route passes near a zone that had a NOTAM in the last 48 hours
//   - Unusual aircraft type for the declared flight type
//   - Endurance significantly shorter than route EET
//
// Runs on: Ollama local (llama3.1:8b-instruct-q4_K_M) — 8GB RAM compatible
// Port: 3104
// ─────────────────────────────────────────────────────────────────────────────

import express from 'express'
import { createServiceLogger } from './logger'

const app = express()
app.use(express.json())
const log = createServiceLogger('AnomalyAdvisor')

const OLLAMA_URL = process.env.OLLAMA_URL ?? 'http://localhost:11434'
const MODEL      = process.env.ANOMALY_MODEL ?? 'llama3.1:8b-instruct-q4_K_M'
const PORT       = parseInt(process.env.PORT ?? '3104')

const SYSTEM_PROMPT = `You are a flight operations anomaly detection assistant.
You review a newly filed flight plan and its context, then identify anything unusual that an approving officer should be aware of.

STRICT RULES:
1. You produce ADVISORIES only — never recommendations to block, reject, or deny.
2. Each flag must state exactly what is unusual and why it is worth the officer's attention.
3. Do not speculate about intent. Report observable patterns only.
4. If nothing is unusual, return an empty advisories array.
5. Maximum 5 advisories. Each advisory maximum 2 sentences.

Return ONLY valid JSON:
{
  "advisories": [
    {
      "code": "SHORT_ADVISORY_CODE",
      "severity": "INFO | CAUTION | ATTENTION",
      "message": "plain English description of what is unusual"
    }
  ],
  "reviewedAt": "ISO UTC timestamp",
  "confidence": "HIGH | MEDIUM | LOW"
}`

interface FlightPlanContext {
  // The new flight plan
  callsign:       string
  flightRules:    string
  departureIcao:  string
  destination:    string
  eobt:           string    // DDHHmm
  cruisingLevel:  string
  route:          string
  enduranceHHmm?: string
  totalEetMin?:   number
  operatorId:     string

  // Context — populated by the backend before calling this agent
  operatorRecentPlans?: Array<{
    callsign:      string
    departure:     string
    destination:   string
    filedAtUtc:    string
    status:        string
  }>
  activeNotamsNearRoute?: Array<{
    notamNumber:    string
    type:           string
    summaryOneLine: string
  }>
  filingUtc: string   // When this plan was filed
}

interface AnomalyAdvisory {
  code:     string
  severity: 'INFO' | 'CAUTION' | 'ATTENTION'
  message:  string
}

app.post('/advise', async (req, res) => {
  const start = Date.now()
  const input = req.body as FlightPlanContext

  if (!input.callsign || !input.departureIcao) {
    res.status(400).json({ error: 'CALLSIGN_AND_DEPARTURE_REQUIRED' })
    return
  }

  const userPrompt = `Review this flight plan and context for anomalies:\n\n${JSON.stringify(input, null, 2)}`

  try {
    const ollamaRes = await fetch(`${OLLAMA_URL}/api/chat`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model:  MODEL,
        stream: false,
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          { role: 'user',   content: userPrompt   },
        ],
        options: { temperature: 0.2, num_predict: 512 }
      })
    })

    if (!ollamaRes.ok) {
      throw new Error(`Ollama returned ${ollamaRes.status}`)
    }

    const ollamaData = await ollamaRes.json() as { message: { content: string } }
    const rawText    = ollamaData.message.content.trim()
    const latencyMs  = Date.now() - start

    let parsed: { advisories: AnomalyAdvisory[], confidence: string } = { advisories: [], confidence: 'LOW' }
    try {
      const cleaned = rawText.replace(/^```json\s*/i, '').replace(/```\s*$/i, '').trim()
      parsed = JSON.parse(cleaned)
    } catch {
      log.warn('anomaly_parse_failed', { data: { callsign: input.callsign } })
      // Return empty advisories on parse failure — never block the workflow
    }

    // Cap at 5 advisories — enforce the system prompt rule in code
    const advisories = (parsed.advisories ?? []).slice(0, 5)

    log.info('anomaly_review_complete', {
      data: {
        callsign:       input.callsign,
        advisoryCount:  advisories.length,
        confidence:     parsed.confidence,
        latencyMs,
      }
    })

    res.json({
      success:    true,
      advisories,
      confidence: parsed.confidence ?? 'LOW',
      _agentModel:     MODEL,
      _agentLatencyMs: latencyMs,
    })

  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : String(e)
    log.error('anomaly_advise_error', { data: { error: msg } })
    // On failure — return empty advisories, never block the workflow
    res.json({
      success:    true,
      advisories: [],
      confidence: 'LOW',
      _agentModel:     MODEL,
      _agentLatencyMs: Date.now() - start,
      _agentError:     msg,
    })
  }
})

app.get('/health', async (_req, res) => {
  try {
    const r = await fetch(`${OLLAMA_URL}/api/tags`)
    res.json({ status: r.ok ? 'ok' : 'ollama_unreachable', model: MODEL, port: PORT })
  } catch {
    res.status(503).json({ status: 'ollama_unreachable', model: MODEL })
  }
})

app.listen(PORT, () => {
  log.info('anomaly_advisor_started', { data: { port: PORT, model: MODEL } })
})

export default app
