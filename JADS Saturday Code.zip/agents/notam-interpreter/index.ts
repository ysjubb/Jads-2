// ─────────────────────────────────────────────────────────────────────────────
// JADS AI Agent 1 — NOTAM Interpreter
// File: jads-agents/notam-interpreter/index.ts
//
// What it does:
//   Reads raw NOTAM text (e.g. "A0234/24 NOTAMN Q) VIDF/QRTCA/IV/NBO/W/000/050/...")
//   Returns structured JSON: affected polygon, altitude band, time window, type.
//
// Why it exists:
//   Raw NOTAMs are plain text in ICAO format — machines cannot act on them
//   without parsing. This agent converts them to structured data the backend
//   can use to automatically flag conflicting flight plans.
//
// Country-aware from day one:
//   Accepts countryCode parameter. IN = Indian AIP format.
//   EU = EUROCONTROL format (add later). US = FAA/TFR format (add later).
//   Same interface, different system prompts per country.
//
// Runs on: Ollama local (llama3.1:8b-instruct-q4_K_M) — 8GB RAM compatible
// Port: 3101
// ─────────────────────────────────────────────────────────────────────────────

import express from 'express'
import { createServiceLogger } from './logger'

const app = express()
app.use(express.json())
const log = createServiceLogger('NotamInterpreter')

const OLLAMA_URL = process.env.OLLAMA_URL ?? 'http://localhost:11434'
const MODEL      = process.env.NOTAM_MODEL ?? 'llama3.1:8b-instruct-q4_K_M'
const PORT       = parseInt(process.env.PORT ?? '3101')

// ── Country-specific system prompts ──────────────────────────────────────────
// Add EU and US prompts here when expanding. The handler below picks by countryCode.
const SYSTEM_PROMPTS: Record<string, string> = {
  IN: `You are an aviation data extraction assistant trained on Indian AIP and ICAO NOTAM formats.
Extract structured information from a raw NOTAM string.

Return ONLY valid JSON with no markdown, no backticks, no explanation. The JSON must have:
{
  "notamNumber": "string — e.g. A0234/24",
  "type": "one of: RESTRICTED_AREA | PROHIBITED_AREA | DANGER_AREA | AERODROME_CLOSED | RUNWAY_CLOSED | NAVAID_OUTAGE | VIP_MOVEMENT | EXERCISE | OTHER",
  "affectedIcao": "4-letter ICAO code if aerodrome-specific, else null",
  "lowerAltFt": number — lower altitude in feet (0 if surface),
  "upperAltFt": number — upper altitude in feet (999999 if unlimited),
  "effectiveFrom": "ISO 8601 UTC datetime string",
  "effectiveTo": "ISO 8601 UTC datetime string, or null if PERM",
  "isPermanent": boolean,
  "summaryOneLine": "one plain English sentence describing the restriction",
  "rawQ": "the Q) line from the NOTAM if present, else null"
}

If any field cannot be determined from the NOTAM text, use null for that field.
Never guess or fabricate coordinates or times. Return null if uncertain.`,

  // Placeholder for future expansion — do not remove
  EU: `You are an aviation data extraction assistant trained on EUROCONTROL NOTAM formats.
[EU-specific prompt goes here when expanding to EU market]
Return ONLY valid JSON matching the same schema as IN.`,

  US: `You are an aviation data extraction assistant trained on FAA NOTAM and TFR formats.
[US-specific prompt goes here when expanding to US market]
Return ONLY valid JSON matching the same schema as IN.`,
}

// ── Interfaces ────────────────────────────────────────────────────────────────
interface NotamInterpretRequest {
  rawNotam:    string        // The raw NOTAM text
  countryCode: string        // 'IN' | 'EU' | 'US'
  context?:    string        // Optional — e.g. departure aerodrome, to help with relevance
}

interface NotamInterpretResult {
  notamNumber:    string | null
  type:           string | null
  affectedIcao:   string | null
  lowerAltFt:     number | null
  upperAltFt:     number | null
  effectiveFrom:  string | null
  effectiveTo:    string | null
  isPermanent:    boolean
  summaryOneLine: string | null
  rawQ:           string | null
  // Agent metadata — always included
  _agentModel:    string
  _agentLatencyMs: number
  _parseSuccess:  boolean
  _parseError?:   string
}

// ── Main interpret endpoint ───────────────────────────────────────────────────
app.post('/interpret', async (req, res) => {
  const start = Date.now()
  const { rawNotam, countryCode = 'IN', context } = req.body as NotamInterpretRequest

  if (!rawNotam || rawNotam.trim() === '') {
    res.status(400).json({ error: 'RAW_NOTAM_REQUIRED' })
    return
  }

  const systemPrompt = SYSTEM_PROMPTS[countryCode.toUpperCase()]
  if (!systemPrompt) {
    res.status(400).json({ error: `UNSUPPORTED_COUNTRY_CODE: ${countryCode}. Supported: ${Object.keys(SYSTEM_PROMPTS).join(', ')}` })
    return
  }

  const userPrompt = context
    ? `NOTAM text:\n${rawNotam}\n\nContext: This NOTAM is being evaluated for a flight departing from ${context}.`
    : `NOTAM text:\n${rawNotam}`

  try {
    // Call Ollama
    const ollamaRes = await fetch(`${OLLAMA_URL}/api/chat`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model:  MODEL,
        stream: false,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user',   content: userPrompt   },
        ],
        options: {
          temperature: 0,      // Deterministic — this is data extraction, not creative writing
          num_predict: 512,    // NOTAM JSON responses are short
        }
      })
    })

    if (!ollamaRes.ok) {
      throw new Error(`Ollama returned ${ollamaRes.status}: ${await ollamaRes.text()}`)
    }

    const ollamaData = await ollamaRes.json() as { message: { content: string } }
    const rawText    = ollamaData.message.content.trim()
    const latencyMs  = Date.now() - start

    // Parse the JSON response — never trust the model output directly
    let parsed: Record<string, unknown>
    let parseSuccess = true
    let parseError: string | undefined

    try {
      // Strip any accidental markdown code fences the model might add
      const cleaned = rawText.replace(/^```json\s*/i, '').replace(/```\s*$/i, '').trim()
      parsed = JSON.parse(cleaned)
    } catch (e) {
      parseSuccess = false
      parseError   = `JSON parse failed: ${e instanceof Error ? e.message : String(e)}`
      parsed       = {}
      log.warn('notam_parse_failed', { data: { rawText: rawText.substring(0, 200), error: parseError } })
    }

    // Log every interpretation for audit purposes
    log.info('notam_interpreted', {
      data: {
        countryCode,
        notamNumber:    parsed.notamNumber ?? null,
        type:           parsed.type ?? null,
        latencyMs,
        parseSuccess,
        model: MODEL,
      }
    })

    const result: NotamInterpretResult = {
      notamNumber:    (parsed.notamNumber    as string  | null) ?? null,
      type:           (parsed.type           as string  | null) ?? null,
      affectedIcao:   (parsed.affectedIcao   as string  | null) ?? null,
      lowerAltFt:     (parsed.lowerAltFt     as number  | null) ?? null,
      upperAltFt:     (parsed.upperAltFt     as number  | null) ?? null,
      effectiveFrom:  (parsed.effectiveFrom  as string  | null) ?? null,
      effectiveTo:    (parsed.effectiveTo    as string  | null) ?? null,
      isPermanent:    (parsed.isPermanent    as boolean)        ?? false,
      summaryOneLine: (parsed.summaryOneLine as string  | null) ?? null,
      rawQ:           (parsed.rawQ           as string  | null) ?? null,
      _agentModel:     MODEL,
      _agentLatencyMs: latencyMs,
      _parseSuccess:   parseSuccess,
      ...(parseError ? { _parseError: parseError } : {}),
    }

    res.json({ success: true, result })

  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : String(e)
    log.error('notam_interpret_error', { data: { error: msg } })
    res.status(502).json({ error: 'OLLAMA_CALL_FAILED', detail: msg })
  }
})

// ── Health check ─────────────────────────────────────────────────────────────
app.get('/health', async (_req, res) => {
  try {
    const r = await fetch(`${OLLAMA_URL}/api/tags`)
    const ok = r.ok
    res.json({ status: ok ? 'ok' : 'ollama_unreachable', model: MODEL, port: PORT })
  } catch {
    res.status(503).json({ status: 'ollama_unreachable', model: MODEL })
  }
})

app.listen(PORT, () => {
  log.info('notam_interpreter_started', { data: { port: PORT, model: MODEL, ollamaUrl: OLLAMA_URL } })
})

export default app
