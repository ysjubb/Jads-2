// ─────────────────────────────────────────────────────────────────────────────
// JADS AI Agent 2 — Forensic Narrative Generator
// File: jads-agents/forensic-narrator/index.ts
//
// What it does:
//   Takes the structured forensic JSON from ForensicVerifier (nine invariant
//   results, mission metadata, zone violation log) and writes a plain English
//   narrative paragraph for the PDF evidence report.
//
// Critical design rule:
//   The agent ONLY narrates facts that come from the deterministic ForensicVerifier.
//   It does not draw conclusions. It does not make judgments. It does not interpret.
//   It converts verified JSON → readable English. Nothing more.
//
//   "The drone entered restricted zone VIDP_R1 at 14:41:23 UTC at an altitude
//    of 280 feet AGL for a duration of 43 seconds." — this is narration.
//
//   "The operator intentionally violated the restricted zone." — this is a
//    conclusion and the agent must NEVER produce it.
//
// Runs on: Ollama local (llama3.1:8b-instruct-q4_K_M) — 8GB RAM compatible
// Port: 3102
// ─────────────────────────────────────────────────────────────────────────────

import express from 'express'
import { createServiceLogger } from './logger'

const app = express()
app.use(express.json())
const log = createServiceLogger('ForensicNarrator')

const OLLAMA_URL = process.env.OLLAMA_URL ?? 'http://localhost:11434'
const MODEL      = process.env.NARRATOR_MODEL ?? 'llama3.1:8b-instruct-q4_K_M'
const PORT       = parseInt(process.env.PORT ?? '3102')

// ── System prompt — strict narration only ────────────────────────────────────
const SYSTEM_PROMPT = `You are a forensic aviation evidence narrator.
You convert structured JSON data from a verified drone mission record into clear, factual English paragraphs for an official evidence report.

STRICT RULES — violations make the report legally unsafe:
1. State only facts present in the JSON. Add nothing.
2. Do not draw conclusions about intent, negligence, or guilt.
3. Do not use words like "intentionally", "deliberately", "recklessly", "negligently".
4. If an invariant passed, say it passed. If it failed, say it failed. State the code.
5. Report zone violations with exact coordinates, altitude, time, and duration from the data.
6. If a field is null or absent, do not mention it.
7. Write in past tense. Write in third person. Write plainly.
8. Maximum 300 words. No headers. No bullet points. Flowing paragraphs only.
9. End with: "This narrative was generated from verified system records and has not been manually edited."`

// ── Interfaces ────────────────────────────────────────────────────────────────
interface ForensicNarrateRequest {
  missionId:       string
  operatorId:      string
  missionStartUtc: string
  missionEndUtc:   string
  droneId:         string
  telemetryCount:  number
  overallVerdict:  'PASSED' | 'FAILED' | 'DEGRADED'
  invariantResults: Array<{
    code:     string    // e.g. I1_HASH_CHAIN
    label:    string
    pass:     boolean
    critical: boolean
    detail?:  string
  }>
  zoneViolations: Array<{
    zoneName:      string
    entryUtc:      string
    exitUtc:       string | null
    durationSec:   number
    latDeg:        number
    lonDeg:        number
    altitudeFtAgl: number
  }>
}

// ── Main narrate endpoint ─────────────────────────────────────────────────────
app.post('/narrate', async (req, res) => {
  const start = Date.now()
  const input = req.body as ForensicNarrateRequest

  if (!input.missionId || !input.overallVerdict) {
    res.status(400).json({ error: 'MISSION_ID_AND_VERDICT_REQUIRED' })
    return
  }

  // Build a compact but complete JSON summary to feed to the model
  // We do NOT send the raw telemetry bytes — only the verified summary
  const dataForModel = {
    mission: {
      id:              input.missionId,
      operatorId:      input.operatorId,
      droneId:         input.droneId,
      startUtc:        input.missionStartUtc,
      endUtc:          input.missionEndUtc,
      telemetryRecords: input.telemetryCount,
      overallVerdict:  input.overallVerdict,
    },
    invariants: input.invariantResults.map(i => ({
      code:     i.code,
      label:    i.label,
      passed:   i.pass,
      critical: i.critical,
      detail:   i.detail ?? null,
    })),
    zoneViolations: input.zoneViolations.map(v => ({
      zone:        v.zoneName,
      entryUtc:    v.entryUtc,
      exitUtc:     v.exitUtc,
      durationSec: v.durationSec,
      lat:         v.latDeg.toFixed(6),
      lon:         v.lonDeg.toFixed(6),
      altFtAgl:    v.altitudeFtAgl,
    })),
  }

  const userPrompt = `Write the forensic narrative for this drone mission record:\n\n${JSON.stringify(dataForModel, null, 2)}`

  try {
    const ollamaRes = await fetch(`${OLLAMA_URL}/api/chat`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model:  MODEL,
        stream: false,
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          { role: 'user',   content: userPrompt   },
        ],
        options: {
          temperature: 0.1,   // Very low — we want consistent, factual output
          num_predict: 512,
        }
      })
    })

    if (!ollamaRes.ok) {
      throw new Error(`Ollama returned ${ollamaRes.status}`)
    }

    const ollamaData = await ollamaRes.json() as { message: { content: string } }
    const narrative  = ollamaData.message.content.trim()
    const latencyMs  = Date.now() - start

    // Safety check — reject if the model produced any prohibited judgment words
    const prohibitedWords = ['intentionally', 'deliberately', 'recklessly', 'negligently', 'guilty', 'innocent']
    const foundProhibited = prohibitedWords.filter(w => narrative.toLowerCase().includes(w))

    if (foundProhibited.length > 0) {
      log.warn('narrative_prohibited_words', {
        data: { missionId: input.missionId, foundWords: foundProhibited }
      })
      // Return a safe fallback rather than a legally unsafe narrative
      res.json({
        success:   true,
        narrative: buildFallbackNarrative(input),
        _agentModel: MODEL,
        _agentLatencyMs: latencyMs,
        _usedFallback: true,
        _fallbackReason: `Prohibited judgment words detected: ${foundProhibited.join(', ')}`,
      })
      return
    }

    log.info('narrative_generated', {
      data: { missionId: input.missionId, latencyMs, wordCount: narrative.split(' ').length }
    })

    res.json({
      success:         true,
      narrative,
      _agentModel:     MODEL,
      _agentLatencyMs: latencyMs,
      _usedFallback:   false,
    })

  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : String(e)
    log.error('narrative_generation_error', { data: { error: msg, missionId: input.missionId } })

    // Never fail the PDF report — return deterministic fallback
    res.json({
      success:         true,
      narrative:       buildFallbackNarrative(input),
      _agentModel:     MODEL,
      _agentLatencyMs: Date.now() - start,
      _usedFallback:   true,
      _fallbackReason: msg,
    })
  }
})

// ── Deterministic fallback — used when the model fails or produces unsafe output ─
// This is why the agent is never on the critical path — the fallback is always safe.
function buildFallbackNarrative(input: ForensicNarrateRequest): string {
  const passed   = input.invariantResults.filter(i => i.pass).length
  const failed   = input.invariantResults.filter(i => !i.pass && i.critical).length
  const advisory = input.invariantResults.filter(i => !i.pass && !i.critical).length

  let text = `Mission ${input.missionId} was conducted by operator ${input.operatorId} using drone ${input.droneId}. `
  text += `The mission commenced at ${input.missionStartUtc} UTC and concluded at ${input.missionEndUtc} UTC. `
  text += `${input.telemetryCount} telemetry records were recorded. `
  text += `Forensic verification produced an overall verdict of ${input.overallVerdict}. `
  text += `Of nine invariants checked: ${passed} passed, ${failed} failed (critical), ${advisory} produced advisory flags. `

  if (input.zoneViolations.length === 0) {
    text += 'No restricted zone violations were detected. '
  } else {
    text += `${input.zoneViolations.length} zone violation(s) were recorded. `
    for (const v of input.zoneViolations) {
      text += `Zone ${v.zoneName} was entered at ${v.entryUtc} UTC at an altitude of ${v.altitudeFtAgl} feet AGL `
      text += `(coordinates: ${v.latDeg.toFixed(4)}°N, ${v.lonDeg.toFixed(4)}°E) for a duration of ${v.durationSec} seconds. `
    }
  }

  text += 'This narrative was generated from verified system records and has not been manually edited.'
  return text
}

// ── Health check ─────────────────────────────────────────────────────────────
app.get('/health', async (_req, res) => {
  try {
    const r = await fetch(`${OLLAMA_URL}/api/tags`)
    res.json({ status: r.ok ? 'ok' : 'ollama_unreachable', model: MODEL, port: PORT })
  } catch {
    res.status(503).json({ status: 'ollama_unreachable', model: MODEL })
  }
})

app.listen(PORT, () => {
  log.info('forensic_narrator_started', { data: { port: PORT, model: MODEL } })
})

export default app
