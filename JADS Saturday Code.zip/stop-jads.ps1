# ─────────────────────────────────────────────────────────────────────────────
# JADS Stop Script
# File: C:\JADS\stop-jads.ps1
#
# Kills all JADS processes that were started by start-jads.ps1.
# Also stops the PostgreSQL Docker container.
#
# HOW TO RUN:
#   cd C:\JADS
#   .\stop-jads.ps1
# ─────────────────────────────────────────────────────────────────────────────

$JADS_ROOT = $PSScriptRoot
$pidFile   = Join-Path $JADS_ROOT ".jads-pids.txt"

function Write-Step { param($msg) Write-Host "`n▶  $msg" -ForegroundColor Cyan }
function Write-OK   { param($msg) Write-Host "   ✓  $msg" -ForegroundColor Green }
function Write-Warn { param($msg) Write-Host "   ⚠  $msg" -ForegroundColor Yellow }

Write-Host ""
Write-Host "  ╔══════════════════════════════════════════════════╗" -ForegroundColor DarkRed
Write-Host "  ║              JADS — STOPPING ALL SERVICES         ║" -ForegroundColor DarkRed
Write-Host "  ╚══════════════════════════════════════════════════╝" -ForegroundColor DarkRed
Write-Host ""

# ── Kill tracked PIDs ─────────────────────────────────────────────────────────
Write-Step "Stopping JADS processes"

if (Test-Path $pidFile) {
    $lines = Get-Content $pidFile | Where-Object { $_ -notmatch "^#" -and $_ -match "=" }
    foreach ($line in $lines) {
        $parts = $line -split "="
        $name  = $parts[0].Trim()
        $pid   = [int]$parts[1].Trim()
        try {
            $proc = Get-Process -Id $pid -ErrorAction Stop
            Stop-Process -Id $pid -Force
            Write-OK "Stopped $name (PID $pid)"
        } catch {
            Write-Warn "$name (PID $pid) — already stopped or not found"
        }
    }
    Remove-Item $pidFile -Force
} else {
    Write-Warn "No PID file found — trying to find processes by port"

    # Kill by port as fallback
    $ports = @(8080, 5173, 5174, 3101, 3102, 3103, 3104, 11434)
    foreach ($port in $ports) {
        $conn = netstat -ano 2>&1 | Select-String ":$port " | Select-Object -First 1
        if ($conn) {
            $pid = ($conn -split '\s+')[-1]
            try {
                Stop-Process -Id $pid -Force -ErrorAction Stop
                Write-OK "Killed process on port $port (PID $pid)"
            } catch {
                Write-Warn "Could not kill process on port $port"
            }
        }
    }
}

# ── Stop node processes that may have been spawned as children ────────────────
Write-Step "Cleaning up Node.js processes"
$nodeProcs = Get-Process -Name "node" -ErrorAction SilentlyContinue
if ($nodeProcs) {
    # Only kill node processes running from the JADS directory
    foreach ($proc in $nodeProcs) {
        try {
            $cmdLine = (Get-WmiObject Win32_Process -Filter "ProcessId=$($proc.Id)").CommandLine
            if ($cmdLine -like "*jads*") {
                Stop-Process -Id $proc.Id -Force
                Write-OK "Stopped Node.js process (PID $($proc.Id))"
            }
        } catch { }
    }
} else {
    Write-Warn "No Node.js processes found"
}

# ── Stop PostgreSQL Docker container ──────────────────────────────────────────
Write-Step "Stopping PostgreSQL"
$dbRunning = docker ps --filter "name=jads-db" --format "{{.Names}}" 2>&1
if ($dbRunning -match "jads-db") {
    docker stop jads-db 2>&1 | Out-Null
    Write-OK "PostgreSQL stopped"
} else {
    Write-Warn "PostgreSQL container not running"
}

Write-Host ""
Write-Host "  All JADS services stopped." -ForegroundColor Green
Write-Host "  Run .\start-jads.ps1 to start again." -ForegroundColor Gray
Write-Host ""
