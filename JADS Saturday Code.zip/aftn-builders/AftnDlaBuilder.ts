// AftnDlaBuilder — produces a valid ICAO Doc 4444 DLA (delay) message.
//
// MANDATORY invariants (enforced with hard throws):
//   - Message MUST start with (DLA-
//   - Message MUST end with )
//   - newEobt MUST be after original eobt — delay cannot move departure earlier
//   - atsRef MUST be provided — cannot delay a plan that was never filed
//
// When to send DLA:
//   - Aircraft ready but departure delayed — new EOBT known
//   - Ground hold issued by ATC
//   - Operator updates estimated off-block time in the admin portal
//
// Purpose — prevents unnecessary SAR activation:
//   Without DLA, ATC will initiate ALERTING when the aircraft does not
//   depart at the filed EOBT. DLA tells them to expect a later departure.
//   This is the primary operational reason this message exists.
//
// ICAO Doc 4444 §4.7.4 — DLA format:
//   (DLA-CALLSIGN-ADEP-EOBT-ADES-NEEOBT-)
//   Where NEEOBT = New Estimated Off-Block Time in DDHHmm

import { createServiceLogger } from '../logger'

const log = createServiceLogger('AftnDlaBuilder')

export interface AftnDlaInput {
  callsign:      string   // e.g. VT-ABC or IAF123
  departureIcao: string   // 4-letter ICAO code
  originalEobt:  string   // Original filed EOBT in DDHHmm
  newEobt:       string   // New EOBT in DDHHmm — must be later than original
  destination:   string   // 4-letter ICAO code
  atsRef:        string   // ATS reference from original FPL filing
  reason?:       string   // Free-text delay reason — appended as RMK/
}

export interface AftnDlaResult {
  message:     string   // Full DLA message body
  builtAtUtc:  string   // ISO timestamp when DLA was built
  atsRef:      string
  originalEobt: string
  newEobt:     string
}

export class AftnDlaBuilder {

  build(input: AftnDlaInput): AftnDlaResult {
    this.validate(input)

    const builtAtUtc = new Date().toISOString()

    // ── DLA body per ICAO Doc 4444 §4.7.4 ──────────────────────────────
    // Format: (DLA-CALLSIGN-ADEP-EOBT-ADES-NEEOBT-)
    let message = `(DLA-${input.callsign}-${input.departureIcao}-${input.originalEobt}-${input.destination}-${input.newEobt}-`

    if (input.reason) {
      const safeReason = input.reason
        .replace(/[-()]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .toUpperCase()
        .substring(0, 64)
      message += `0/RMK/${safeReason} `
    }

    message += ')'

    if (!message.startsWith('(DLA-')) {
      throw new Error('DLA_BUILDER_INVARIANT: message does not start with (DLA-')
    }

    if (!message.endsWith(')')) {
      throw new Error('DLA_BUILDER_INVARIANT: message does not end with )')
    }

    log.info('dla_built', {
      data: {
        callsign:     input.callsign,
        atsRef:       input.atsRef,
        originalEobt: input.originalEobt,
        newEobt:      input.newEobt,
        delayMinutes: this.eobtDiffMinutes(input.originalEobt, input.newEobt),
      }
    })

    return {
      message,
      builtAtUtc,
      atsRef:       input.atsRef,
      originalEobt: input.originalEobt,
      newEobt:      input.newEobt,
    }
  }

  // ── Parse DDHHmm into comparable integer (day * 1440 + hours * 60 + min) ─
  private eobtToMinutes(eobt: string): number {
    const day  = parseInt(eobt.substring(0, 2))
    const hour = parseInt(eobt.substring(2, 4))
    const min  = parseInt(eobt.substring(4, 6))
    return day * 1440 + hour * 60 + min
  }

  private eobtDiffMinutes(original: string, newEobt: string): number {
    return this.eobtToMinutes(newEobt) - this.eobtToMinutes(original)
  }

  private validate(input: AftnDlaInput): void {
    if (!input.atsRef || input.atsRef.trim() === '') {
      throw new Error('DLA_REQUIRES_ATS_REF: cannot delay a plan with no ATS reference')
    }

    if (!input.callsign || !/^[A-Z0-9]{2,8}$/.test(input.callsign)) {
      throw new Error(`DLA_INVALID_CALLSIGN: "${input.callsign}"`)
    }

    if (!input.departureIcao || !/^[A-Z]{4}$/.test(input.departureIcao)) {
      throw new Error(`DLA_INVALID_ADEP: "${input.departureIcao}"`)
    }

    if (!input.destination || !/^[A-Z]{4}$/.test(input.destination)) {
      throw new Error(`DLA_INVALID_ADES: "${input.destination}"`)
    }

    if (!input.originalEobt || !/^\d{6}$/.test(input.originalEobt)) {
      throw new Error(`DLA_INVALID_ORIGINAL_EOBT: "${input.originalEobt}" — must be DDHHmm`)
    }

    if (!input.newEobt || !/^\d{6}$/.test(input.newEobt)) {
      throw new Error(`DLA_INVALID_NEW_EOBT: "${input.newEobt}" — must be DDHHmm`)
    }

    // New EOBT must be strictly later than original
    if (this.eobtToMinutes(input.newEobt) <= this.eobtToMinutes(input.originalEobt)) {
      throw new Error(
        `DLA_NEW_EOBT_NOT_LATER: newEobt ${input.newEobt} is not after originalEobt ${input.originalEobt}`
      )
    }
  }
}
