// AftnCnlBuilder — produces a valid ICAO Doc 4444 CNL (cancellation) message.
//
// MANDATORY invariants (enforced with hard throws):
//   - Message MUST start with (CNL-
//   - Message MUST end with )
//   - atsRef MUST be provided — cannot cancel a plan that was never filed
//   - cancellationTime is always the current UTC moment — never caller-supplied
//
// When to send CNL:
//   - Flight plan filed but departure cancelled before EOBT
//   - Operator explicitly cancels through the admin portal
//   - System auto-cancels after configurable timeout with no departure
//
// ICAO Doc 4444 §4.7.2 — CNL format:
//   (CNL-CALLSIGN-ADEP-EOBT-ADES-)
//
// Note: ARR message type is NOT implemented. Arrival confirmation requires
// real-time ATC monitoring which is outside this platform's scope.

import { createServiceLogger } from '../logger'

const log = createServiceLogger('AftnCnlBuilder')

export interface AftnCnlInput {
  callsign:      string   // e.g. VT-ABC or IAF123
  departureIcao: string   // 4-letter ICAO code — e.g. VIDP
  eobt:          string   // Original EOBT in DDHHmm format — e.g. 151430
  destination:   string   // 4-letter ICAO code — e.g. VOMM
  atsRef:        string   // ATS reference from original FPL filing — mandatory
  reason?:       string   // Free-text reason — included in Item 18 if provided
}

export interface AftnCnlResult {
  message:           string   // Full CNL message body
  cancellationUtc:   string   // ISO timestamp of when CNL was built
  atsRef:            string   // Original ATS ref being cancelled
}

export class AftnCnlBuilder {

  build(input: AftnCnlInput): AftnCnlResult {
    this.validate(input)

    const cancellationUtc = new Date().toISOString()

    // ── CNL body per ICAO Doc 4444 §4.7.2 ───────────────────────────────
    // Format: (CNL-CALLSIGN-ADEP-EOBT-ADES-)
    // Optional STS/ and RMK/ fields appended in field 18 if reason provided
    let message = `(CNL-${input.callsign}-${input.departureIcao}-${input.eobt}-${input.destination}-`

    if (input.reason) {
      // Sanitise reason — remove hyphens and parentheses to prevent AFTN injection
      const safeReason = input.reason
        .replace(/[-()]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .toUpperCase()
        .substring(0, 64)  // ICAO free text field limit
      message += `0/RMK/${safeReason} `
    }

    message += ')'

    // Hard invariant — message must start with (CNL-
    if (!message.startsWith('(CNL-')) {
      throw new Error('CNL_BUILDER_INVARIANT: message does not start with (CNL-')
    }

    // Hard invariant — message must end with )
    if (!message.endsWith(')')) {
      throw new Error('CNL_BUILDER_INVARIANT: message does not end with )')
    }

    log.info('cnl_built', {
      data: {
        callsign:  input.callsign,
        atsRef:    input.atsRef,
        departure: input.departureIcao,
        dest:      input.destination,
        hasReason: !!input.reason,
      }
    })

    return {
      message,
      cancellationUtc,
      atsRef: input.atsRef,
    }
  }

  private validate(input: AftnCnlInput): void {
    if (!input.atsRef || input.atsRef.trim() === '') {
      throw new Error('CNL_REQUIRES_ATS_REF: cannot cancel a plan with no ATS reference')
    }

    if (!input.callsign || !/^[A-Z0-9]{2,8}$/.test(input.callsign)) {
      throw new Error(`CNL_INVALID_CALLSIGN: "${input.callsign}"`)
    }

    if (!input.departureIcao || !/^[A-Z]{4}$/.test(input.departureIcao)) {
      throw new Error(`CNL_INVALID_ADEP: "${input.departureIcao}"`)
    }

    if (!input.destination || !/^[A-Z]{4}$/.test(input.destination)) {
      throw new Error(`CNL_INVALID_ADES: "${input.destination}"`)
    }

    if (!input.eobt || !/^\d{6}$/.test(input.eobt)) {
      throw new Error(`CNL_INVALID_EOBT: "${input.eobt}" — must be DDHHmm`)
    }
  }
}
