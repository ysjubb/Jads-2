// ─────────────────────────────────────────────────────────────────────────────
// ADDITIONS TO FlightPlanService.ts
//
// Add these two methods to the existing FlightPlanService class.
// Also add these imports at the top of FlightPlanService.ts:
//
//   import { AftnCnlBuilder } from './AftnCnlBuilder'
//   import { AftnDlaBuilder } from './AftnDlaBuilder'
//
// And add these two private instances in the class body (with the others):
//
//   private cnlBuilder = new AftnCnlBuilder()
//   private dlaBuilder = new AftnDlaBuilder()
//
// ALLOWED STATES FOR CANCEL:
//   VALIDATED, FILED, PENDING_CLEARANCE, ADC_ISSUED, FIC_ISSUED
//   — cannot cancel a plan that is already AIRBORNE or ARRIVED
//
// ALLOWED STATES FOR DELAY:
//   FILED, PENDING_CLEARANCE, ADC_ISSUED, FIC_ISSUED, FULLY_CLEARED
//   — cannot delay a plan that hasn't been filed yet (no atsRef exists)
// ─────────────────────────────────────────────────────────────────────────────

  // ── Cancel a filed flight plan — sends CNL to AFTN ──────────────────────
  async cancelPlan(
    planId:   string,
    userId:   string,
    userType: 'CIVILIAN' | 'SPECIAL',
    reason?:  string
  ): Promise<{ success: boolean; message: string; cnlMessage?: string }> {

    const plan = await this.prisma.mannedFlightPlan.findUnique({
      where: { id: planId }
    })

    if (!plan) {
      throw new Error('FLIGHT_PLAN_NOT_FOUND')
    }

    // State guard — cannot cancel airborne or arrived plans
    const nonCancellableStates = ['AIRBORNE', 'ARRIVED', 'CANCELLED', 'FILING_FAILED']
    if (nonCancellableStates.includes(plan.status)) {
      throw new Error(`CANCEL_NOT_ALLOWED_IN_STATE: ${plan.status}`)
    }

    // Build CNL message if plan was actually filed (has atsRef)
    let cnlMessage: string | undefined
    let cnlResult: AftnCnlResult | undefined

    if (plan.atsRef) {
      cnlResult = this.cnlBuilder.build({
        callsign:      plan.aircraftId,
        departureIcao: plan.adep,
        eobt:          this.dateToEobt(plan.eobt),
        destination:   plan.ades,
        atsRef:        plan.atsRef,
        reason,
      })

      cnlMessage = cnlResult.message

      // Send CNL via gateway
      await this.aftnGateway.cancelFpl(
        plan.atsRef,
        plan.aircraftId,
        plan.adep,
        this.dateToEobt(plan.eobt)
      )
    }

    // Update plan status to CANCELLED
    await this.prisma.mannedFlightPlan.update({
      where: { id: planId },
      data: {
        status:         'CANCELLED' as any,
        cancelledAt:    new Date(),
        cancelReason:   reason ?? null,
        cnlAftnMessage: cnlMessage ?? null,
      }
    })

    await this.writeAuditLog(userId, userType, 'flight_plan_cancelled', planId, true, {
      callsign:    plan.aircraftId,
      atsRef:      plan.atsRef,
      reason:      reason ?? 'not provided',
      cnlBuilt:    !!cnlMessage,
      previousStatus: plan.status,
    })

    log.info('flight_plan_cancelled', {
      data: { planId, callsign: plan.aircraftId, atsRef: plan.atsRef, reason }
    })

    return {
      success:    true,
      message:    `Flight plan ${plan.aircraftId} cancelled`,
      cnlMessage,
    }
  }

  // ── Delay a filed flight plan — sends DLA to AFTN ───────────────────────
  async delayPlan(
    planId:      string,
    newEobt:     string,   // DDHHmm format
    userId:      string,
    userType:    'CIVILIAN' | 'SPECIAL',
    reason?:     string
  ): Promise<{ success: boolean; message: string; dlaMessage?: string; newEobt: string }> {

    const plan = await this.prisma.mannedFlightPlan.findUnique({
      where: { id: planId }
    })

    if (!plan) {
      throw new Error('FLIGHT_PLAN_NOT_FOUND')
    }

    // State guard — must be filed to delay
    const delayableStates = ['FILED', 'PENDING_CLEARANCE', 'ADC_ISSUED', 'FIC_ISSUED', 'FULLY_CLEARED']
    if (!delayableStates.includes(plan.status)) {
      throw new Error(`DELAY_NOT_ALLOWED_IN_STATE: ${plan.status}`)
    }

    if (!plan.atsRef) {
      throw new Error('DELAY_REQUIRES_ATS_REF: plan was not successfully filed')
    }

    const originalEobt = this.dateToEobt(plan.eobt)

    // DlaBuilder validates that newEobt is strictly later — throws if not
    const dlaResult = this.dlaBuilder.build({
      callsign:      plan.aircraftId,
      departureIcao: plan.adep,
      originalEobt,
      newEobt,
      destination:   plan.ades,
      atsRef:        plan.atsRef,
      reason,
    })

    // Update EOBT in DB
    const newEobtDate = this.parseEobt(newEobt)
    await this.prisma.mannedFlightPlan.update({
      where: { id: planId },
      data: {
        eobt:          newEobtDate,
        status:        'FILED' as any,   // stays FILED — DLA doesn't change state
        dlaAftnMessage: dlaResult.message,
        lastDelayedAt:  new Date(),
      }
    })

    await this.writeAuditLog(userId, userType, 'flight_plan_delayed', planId, true, {
      callsign:     plan.aircraftId,
      atsRef:       plan.atsRef,
      originalEobt,
      newEobt,
      reason:       reason ?? 'not provided',
    })

    log.info('flight_plan_delayed', {
      data: {
        planId,
        callsign:     plan.aircraftId,
        atsRef:       plan.atsRef,
        originalEobt,
        newEobt,
      }
    })

    return {
      success:    true,
      message:    `Flight plan ${plan.aircraftId} delayed to EOBT ${newEobt}`,
      dlaMessage: dlaResult.message,
      newEobt,
    }
  }

  // ── Helper — convert Date back to DDHHmm string ─────────────────────────
  private dateToEobt(date: Date): string {
    const d = new Date(date)
    const day  = String(d.getUTCDate()).padStart(2, '0')
    const hour = String(d.getUTCHours()).padStart(2, '0')
    const min  = String(d.getUTCMinutes()).padStart(2, '0')
    return `${day}${hour}${min}`
  }

// ─────────────────────────────────────────────────────────────────────────────
// ADDITIONS TO flightPlanRoutes.ts
//
// Add these two routes after the existing GET /:id/events route.
// ─────────────────────────────────────────────────────────────────────────────

// POST /api/flight-plans/:id/cancel
// Cancel a filed flight plan. Sends CNL to AFTN if plan has an atsRef.
// Allowed states: VALIDATED, FILED, PENDING_CLEARANCE, ADC_ISSUED, FIC_ISSUED
router.post('/:id/cancel', requireAuth, async (req, res) => {
  try {
    const result = await fplService.cancelPlan(
      req.params.id,
      req.auth!.userId,
      req.auth!.userType as 'CIVILIAN' | 'SPECIAL',
      req.body.reason
    )
    res.json(serializeForJson({ success: true, ...result }))
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : String(e)
    log.error('cancel_plan_error', { data: { error: msg, planId: req.params.id } })
    if (msg.includes('NOT_FOUND'))           { res.status(404).json({ error: msg }); return }
    if (msg.includes('NOT_ALLOWED_IN_STATE')){ res.status(409).json({ error: msg }); return }
    res.status(500).json({ error: 'CANCEL_FAILED' })
  }
})

// POST /api/flight-plans/:id/delay
// Delay a filed flight plan. Sends DLA to AFTN. New EOBT must be later than current.
// Body: { newEobt: "DDHHmm", reason?: string }
router.post('/:id/delay', requireAuth, async (req, res) => {
  try {
    const { newEobt, reason } = req.body
    if (!newEobt || !/^\d{6}$/.test(newEobt)) {
      res.status(400).json({ error: 'NEW_EOBT_REQUIRED', detail: 'Format: DDHHmm' })
      return
    }
    const result = await fplService.delayPlan(
      req.params.id,
      newEobt,
      req.auth!.userId,
      req.auth!.userType as 'CIVILIAN' | 'SPECIAL',
      reason
    )
    res.json(serializeForJson({ success: true, ...result }))
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : String(e)
    log.error('delay_plan_error', { data: { error: msg, planId: req.params.id } })
    if (msg.includes('NOT_FOUND'))           { res.status(404).json({ error: msg }); return }
    if (msg.includes('NOT_ALLOWED_IN_STATE')){ res.status(409).json({ error: msg }); return }
    if (msg.includes('NOT_LATER'))           { res.status(422).json({ error: msg }); return }
    if (msg.includes('ATS_REF'))             { res.status(422).json({ error: msg }); return }
    res.status(500).json({ error: 'DELAY_FAILED' })
  }
})

// ─────────────────────────────────────────────────────────────────────────────
// PRISMA MIGRATION — add to schema.prisma mannedFlightPlan model
//
// Add these fields to the existing mannedFlightPlan model:
//
//   cancelledAt     DateTime?
//   cancelReason    String?
//   cnlAftnMessage  String?
//   dlaAftnMessage  String?
//   lastDelayedAt   DateTime?
//
// Then run: npx prisma migrate dev --name add_cnl_dla_fields
// ─────────────────────────────────────────────────────────────────────────────
