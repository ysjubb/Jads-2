# ─────────────────────────────────────────────────────────────────────────────
# JADS Saturday Launcher
# File: C:\JADS\start-jads.ps1
#
# What this does, in order:
#   1. Checks all prerequisites (Node, Docker, Ollama, Java)
#   2. Starts PostgreSQL via Docker
#   3. Starts Ollama (if not already running)
#   4. Starts backend server         → http://localhost:8080
#   5. Starts admin portal           → http://localhost:5173
#   6. Starts audit portal           → http://localhost:5174
#   7. Starts all 4 AI agents        → ports 3101-3104
#   8. Builds Android APK            → jads-android/app/build/outputs/apk/debug/
#   9. Runs health checks on everything
#  10. Opens portals in browser
#
# HOW TO RUN:
#   Right-click PowerShell → Run as Administrator
#   cd C:\JADS
#   .\start-jads.ps1
#
# TO STOP EVERYTHING:
#   .\stop-jads.ps1
# ─────────────────────────────────────────────────────────────────────────────

$ErrorActionPreference = "Continue"
$JADS_ROOT = $PSScriptRoot

# ── Colour helpers ────────────────────────────────────────────────────────────
function Write-Step  { param($msg) Write-Host "`n▶  $msg" -ForegroundColor Cyan }
function Write-OK    { param($msg) Write-Host "   ✓  $msg" -ForegroundColor Green }
function Write-Warn  { param($msg) Write-Host "   ⚠  $msg" -ForegroundColor Yellow }
function Write-Fail  { param($msg) Write-Host "   ✗  $msg" -ForegroundColor Red }
function Write-Info  { param($msg) Write-Host "      $msg" -ForegroundColor Gray }

# ── PID tracker — so stop-jads.ps1 knows what to kill ─────────────────────────
$pidFile = Join-Path $JADS_ROOT ".jads-pids.txt"
"# JADS process IDs — written by start-jads.ps1 on $(Get-Date -Format 'yyyy-MM-dd HH:mm')" | Out-File $pidFile

function Track-Pid { param($name, $pid) "$name=$pid" | Add-Content $pidFile }

# ── Wait for HTTP endpoint to respond ─────────────────────────────────────────
function Wait-ForPort {
    param($url, $label, $maxSeconds = 60)
    $elapsed = 0
    Write-Info "Waiting for $label at $url ..."
    while ($elapsed -lt $maxSeconds) {
        try {
            $r = Invoke-WebRequest -Uri $url -TimeoutSec 2 -UseBasicParsing -ErrorAction Stop
            if ($r.StatusCode -lt 500) {
                Write-OK "$label is up ($($r.StatusCode))"
                return $true
            }
        } catch { }
        Start-Sleep -Seconds 2
        $elapsed += 2
    }
    Write-Warn "$label did not respond within ${maxSeconds}s — continuing anyway"
    return $false
}

# ══════════════════════════════════════════════════════════════════════════════
Write-Host ""
Write-Host "  ╔══════════════════════════════════════════════════╗" -ForegroundColor DarkCyan
Write-Host "  ║         JADS PLATFORM — SATURDAY LAUNCHER        ║" -ForegroundColor DarkCyan
Write-Host "  ╚══════════════════════════════════════════════════╝" -ForegroundColor DarkCyan
Write-Host ""

# ══════════════════════════════════════════════════════════════════════════════
# STEP 1 — PREREQUISITES
# ══════════════════════════════════════════════════════════════════════════════
Write-Step "Checking prerequisites"

$prereqOk = $true

# Node.js
try {
    $nodeVer = node --version 2>&1
    Write-OK "Node.js $nodeVer"
} catch {
    Write-Fail "Node.js not found — install from https://nodejs.org"
    $prereqOk = $false
}

# Docker
try {
    $dockerVer = docker --version 2>&1
    Write-OK "Docker: $dockerVer"
} catch {
    Write-Fail "Docker not found — install Docker Desktop"
    $prereqOk = $false
}

# Ollama
$ollamaExe = (Get-Command ollama -ErrorAction SilentlyContinue)
if ($ollamaExe) {
    Write-OK "Ollama found at $($ollamaExe.Source)"
} else {
    Write-Warn "Ollama not found — agents will not start (install from https://ollama.com)"
}

# Java (for Android build)
try {
    $javaVer = java -version 2>&1 | Select-Object -First 1
    Write-OK "Java: $javaVer"
} catch {
    Write-Warn "Java not found — Android APK build will be skipped"
}

if (-not $prereqOk) {
    Write-Host ""
    Write-Fail "One or more required prerequisites are missing. Fix them and re-run."
    exit 1
}

# ══════════════════════════════════════════════════════════════════════════════
# STEP 2 — POSTGRESQL VIA DOCKER
# ══════════════════════════════════════════════════════════════════════════════
Write-Step "Starting PostgreSQL"

$dbRunning = docker ps --filter "name=jads-db" --format "{{.Names}}" 2>&1
if ($dbRunning -match "jads-db") {
    Write-OK "PostgreSQL already running"
} else {
    Write-Info "Starting Docker Compose (PostgreSQL)..."
    $composeFile = Join-Path $JADS_ROOT "jads-backend\docker-compose.yml"
    if (Test-Path $composeFile) {
        Start-Process -FilePath "docker" -ArgumentList "compose -f `"$composeFile`" up -d" -Wait -NoNewWindow
        Start-Sleep -Seconds 4
        Write-OK "PostgreSQL started"
    } else {
        # Fallback — run postgres directly
        docker run -d --name jads-db `
            -e POSTGRES_USER=jads `
            -e POSTGRES_PASSWORD=jads `
            -e POSTGRES_DB=jads `
            -p 5432:5432 `
            postgres:15-alpine 2>&1 | Out-Null
        Start-Sleep -Seconds 5
        Write-OK "PostgreSQL started (direct container)"
    }
}

# Run Prisma migrations (idempotent — safe to run every time)
Write-Info "Running Prisma migrations..."
$backendDir = Join-Path $JADS_ROOT "jads-backend"
$migrateResult = & cmd /c "cd /d `"$backendDir`" && npx prisma migrate deploy 2>&1"
if ($LASTEXITCODE -eq 0) {
    Write-OK "Database schema up to date"
} else {
    Write-Warn "Migration may have issues — check manually if backend fails to start"
    Write-Info $migrateResult
}

# ══════════════════════════════════════════════════════════════════════════════
# STEP 3 — OLLAMA
# ══════════════════════════════════════════════════════════════════════════════
Write-Step "Starting Ollama"

$ollamaRunning = $false
try {
    $r = Invoke-WebRequest -Uri "http://localhost:11434/api/tags" -TimeoutSec 3 -UseBasicParsing -ErrorAction Stop
    Write-OK "Ollama already running"
    $ollamaRunning = $true
} catch {
    if ($ollamaExe) {
        Write-Info "Starting Ollama server..."
        $ollamaProc = Start-Process -FilePath "ollama" -ArgumentList "serve" -PassThru -WindowStyle Hidden
        Track-Pid "ollama" $ollamaProc.Id
        Start-Sleep -Seconds 5
        try {
            $r = Invoke-WebRequest -Uri "http://localhost:11434/api/tags" -TimeoutSec 5 -UseBasicParsing -ErrorAction Stop
            Write-OK "Ollama started (PID $($ollamaProc.Id))"
            $ollamaRunning = $true
        } catch {
            Write-Warn "Ollama did not respond — agents will run but model calls will fail"
        }
    } else {
        Write-Warn "Ollama not installed — skipping"
    }
}

# Check model is available
if ($ollamaRunning) {
    $modelName = "llama3.1:8b-instruct-q4_K_M"
    try {
        $tags = Invoke-WebRequest -Uri "http://localhost:11434/api/tags" -UseBasicParsing | ConvertFrom-Json
        $modelFound = $tags.models | Where-Object { $_.name -like "*llama3.1*" }
        if ($modelFound) {
            Write-OK "Model $modelName available"
        } else {
            Write-Warn "Model not found. Run: ollama pull $modelName"
            Write-Warn "Agents will start but NOTAM/narrative calls will fail until model is pulled"
        }
    } catch {
        Write-Warn "Could not check model list"
    }
}

# ══════════════════════════════════════════════════════════════════════════════
# STEP 4 — BACKEND SERVER
# ══════════════════════════════════════════════════════════════════════════════
Write-Step "Starting backend server (port 8080)"

$backendLog = Join-Path $JADS_ROOT "logs\backend.log"
New-Item -ItemType Directory -Force -Path (Join-Path $JADS_ROOT "logs") | Out-Null

$backendProc = Start-Process `
    -FilePath "cmd" `
    -ArgumentList "/c cd /d `"$backendDir`" && npm run dev > `"$backendLog`" 2>&1" `
    -PassThru -WindowStyle Hidden
Track-Pid "backend" $backendProc.Id
Write-Info "Backend PID $($backendProc.Id) — log: logs\backend.log"
Wait-ForPort "http://localhost:8080/api/health" "Backend" 60

# ══════════════════════════════════════════════════════════════════════════════
# STEP 5 — ADMIN PORTAL (port 5173)
# ══════════════════════════════════════════════════════════════════════════════
Write-Step "Starting admin portal (port 5173)"

$adminDir = Join-Path $JADS_ROOT "jads-admin-portal"
$adminLog  = Join-Path $JADS_ROOT "logs\admin-portal.log"

$adminProc = Start-Process `
    -FilePath "cmd" `
    -ArgumentList "/c cd /d `"$adminDir`" && npm run dev > `"$adminLog`" 2>&1" `
    -PassThru -WindowStyle Hidden
Track-Pid "admin-portal" $adminProc.Id
Write-Info "Admin portal PID $($adminProc.Id) — log: logs\admin-portal.log"
Wait-ForPort "http://localhost:5173" "Admin portal" 45

# ══════════════════════════════════════════════════════════════════════════════
# STEP 6 — AUDIT PORTAL (port 5174)
# ══════════════════════════════════════════════════════════════════════════════
Write-Step "Starting audit portal (port 5174)"

$auditDir = Join-Path $JADS_ROOT "jads-audit-portal"
$auditLog  = Join-Path $JADS_ROOT "logs\audit-portal.log"

$auditProc = Start-Process `
    -FilePath "cmd" `
    -ArgumentList "/c cd /d `"$auditDir`" && npm run dev > `"$auditLog`" 2>&1" `
    -PassThru -WindowStyle Hidden
Track-Pid "audit-portal" $auditProc.Id
Write-Info "Audit portal PID $($auditProc.Id) — log: logs\audit-portal.log"
Wait-ForPort "http://localhost:5174" "Audit portal" 45

# ══════════════════════════════════════════════════════════════════════════════
# STEP 7 — AI AGENTS (ports 3101-3104)
# ══════════════════════════════════════════════════════════════════════════════
Write-Step "Starting AI agent microservices"

$agentsDir = Join-Path $JADS_ROOT "jads-agents"

if (-not (Test-Path $agentsDir)) {
    Write-Warn "jads-agents folder not found at $agentsDir — skipping agents"
    Write-Warn "Create the agents folder first (see Saturday Guide Part 3)"
} else {
    $agents = @(
        @{ name="notam-interpreter"; script="notam-interpreter/index.ts"; port=3101 },
        @{ name="forensic-narrator"; script="forensic-narrator/index.ts"; port=3102 },
        @{ name="aftn-draft";        script="aftn-draft/index.ts";        port=3103 },
        @{ name="anomaly-advisor";   script="anomaly-advisor/index.ts";   port=3104 }
    )

    foreach ($agent in $agents) {
        $agentLog = Join-Path $JADS_ROOT "logs\$($agent.name).log"
        $agentProc = Start-Process `
            -FilePath "cmd" `
            -ArgumentList "/c cd /d `"$agentsDir`" && npx ts-node `"$($agent.script)`" > `"$agentLog`" 2>&1" `
            -PassThru -WindowStyle Hidden
        Track-Pid $agent.name $agentProc.Id
        Write-Info "$($agent.name) PID $($agentProc.Id) — port $($agent.port)"
    }

    # Give agents 10 seconds to start
    Start-Sleep -Seconds 10

    foreach ($agent in $agents) {
        try {
            $r = Invoke-WebRequest -Uri "http://localhost:$($agent.port)/health" `
                -TimeoutSec 5 -UseBasicParsing -ErrorAction Stop
            Write-OK "$($agent.name) — port $($agent.port) responding"
        } catch {
            Write-Warn "$($agent.name) — port $($agent.port) not responding yet (may still be starting)"
        }
    }
}

# ══════════════════════════════════════════════════════════════════════════════
# STEP 8 — ANDROID APK BUILD
# ══════════════════════════════════════════════════════════════════════════════
Write-Step "Building Android APK"

$androidDir    = Join-Path $JADS_ROOT "jads-android"
$gradlewBat    = Join-Path $androidDir "gradlew.bat"
$apkOutputDir  = Join-Path $androidDir "app\build\outputs\apk\debug"
$apkFile       = Join-Path $apkOutputDir "app-debug.apk"

if (-not (Test-Path $gradlewBat)) {
    Write-Warn "gradlew.bat not found at $gradlewBat — skipping APK build"
    Write-Warn "Make sure jads-android folder is at $androidDir"
} else {
    Write-Info "Running Gradle assembleDebug — this takes 3-5 minutes on first run..."
    Write-Info "Subsequent builds are faster (incremental)."

    $buildLog    = Join-Path $JADS_ROOT "logs\android-build.log"
    $buildResult = & cmd /c "cd /d `"$androidDir`" && gradlew.bat assembleDebug > `"$buildLog`" 2>&1"
    $buildExit   = $LASTEXITCODE

    if ($buildExit -eq 0 -and (Test-Path $apkFile)) {
        $apkSize = [math]::Round((Get-Item $apkFile).Length / 1MB, 1)
        Write-OK "APK built successfully — $apkSize MB"
        Write-Info "Location: $apkFile"
        Write-Info ""
        Write-Info "To install on Android device:"
        Write-Info "  1. Enable USB debugging on your phone"
        Write-Info "  2. Connect via USB"
        Write-Info "  3. Run: adb install `"$apkFile`""
    } else {
        Write-Warn "APK build failed — see logs\android-build.log for details"
        Write-Warn "Common causes: Java version mismatch, missing Android SDK"
        Write-Info "To build manually: cd jads-android && gradlew.bat assembleDebug"
    }
}

# ══════════════════════════════════════════════════════════════════════════════
# STEP 9 — FINAL HEALTH CHECK SUMMARY
# ══════════════════════════════════════════════════════════════════════════════
Write-Step "Final health check"
Start-Sleep -Seconds 3

$services = @(
    @{ name="Backend API";      url="http://localhost:8080/api/health" },
    @{ name="Admin Portal";     url="http://localhost:5173" },
    @{ name="Audit Portal";     url="http://localhost:5174" },
    @{ name="Ollama";           url="http://localhost:11434/api/tags" },
    @{ name="NOTAM Interpreter";url="http://localhost:3101/health" },
    @{ name="Forensic Narrator";url="http://localhost:3102/health" },
    @{ name="AFTN Draft";       url="http://localhost:3103/health" },
    @{ name="Anomaly Advisor";  url="http://localhost:3104/health" },
)

$allUp = $true
foreach ($svc in $services) {
    try {
        $r = Invoke-WebRequest -Uri $svc.url -TimeoutSec 4 -UseBasicParsing -ErrorAction Stop
        Write-OK "$($svc.name.PadRight(22)) $($svc.url)"
    } catch {
        Write-Warn "$($svc.name.PadRight(22)) NOT RESPONDING — $($svc.url)"
        $allUp = $false
    }
}

# ══════════════════════════════════════════════════════════════════════════════
# STEP 10 — OPEN PORTALS IN BROWSER
# ══════════════════════════════════════════════════════════════════════════════
Write-Step "Opening portals in browser"
Start-Sleep -Seconds 2

try { Start-Process "http://localhost:5173" } catch { }
Start-Sleep -Seconds 1
try { Start-Process "http://localhost:5174" } catch { }

# ══════════════════════════════════════════════════════════════════════════════
# DONE
# ══════════════════════════════════════════════════════════════════════════════
Write-Host ""
Write-Host "  ─────────────────────────────────────────────────────" -ForegroundColor DarkCyan
if ($allUp) {
    Write-Host "  ✓  All services running. JADS is ready." -ForegroundColor Green
} else {
    Write-Host "  ⚠  Some services are not responding — check logs\ folder." -ForegroundColor Yellow
}
Write-Host ""
Write-Host "  Admin portal  →  http://localhost:5173" -ForegroundColor White
Write-Host "  Audit portal  →  http://localhost:5174" -ForegroundColor White
Write-Host "  Backend API   →  http://localhost:8080" -ForegroundColor White
Write-Host ""
Write-Host "  Logs          →  $JADS_ROOT\logs\" -ForegroundColor Gray
Write-Host "  Stop all      →  .\stop-jads.ps1" -ForegroundColor Gray
Write-Host "  ─────────────────────────────────────────────────────" -ForegroundColor DarkCyan
Write-Host ""
