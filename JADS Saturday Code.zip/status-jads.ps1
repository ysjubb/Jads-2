# ─────────────────────────────────────────────────────────────────────────────
# JADS Status Check
# File: C:\JADS\status-jads.ps1
#
# Run this at any time to see what is and isn't running.
# Does NOT start or stop anything.
#
# HOW TO RUN:
#   cd C:\JADS
#   .\status-jads.ps1
# ─────────────────────────────────────────────────────────────────────────────

function Write-Up   { param($name,$url) Write-Host "  ✓  $($name.PadRight(24)) $url" -ForegroundColor Green }
function Write-Down { param($name,$url) Write-Host "  ✗  $($name.PadRight(24)) $url" -ForegroundColor Red }

Write-Host ""
Write-Host "  JADS Platform — Status Check — $(Get-Date -Format 'HH:mm:ss')" -ForegroundColor Cyan
Write-Host "  ──────────────────────────────────────────────────────" -ForegroundColor DarkCyan
Write-Host ""

$services = @(
    @{ name="Backend API";       url="http://localhost:8080/api/health" },
    @{ name="Admin Portal";      url="http://localhost:5173" },
    @{ name="Audit Portal";      url="http://localhost:5174" },
    @{ name="Ollama";            url="http://localhost:11434/api/tags" },
    @{ name="NOTAM Interpreter"; url="http://localhost:3101/health" },
    @{ name="Forensic Narrator"; url="http://localhost:3102/health" },
    @{ name="AFTN Draft";        url="http://localhost:3103/health" },
    @{ name="Anomaly Advisor";   url="http://localhost:3104/health" },
)

$upCount = 0
foreach ($svc in $services) {
    try {
        $r = Invoke-WebRequest -Uri $svc.url -TimeoutSec 3 -UseBasicParsing -ErrorAction Stop
        Write-Up $svc.name $svc.url
        $upCount++
    } catch {
        Write-Down $svc.name $svc.url
    }
}

Write-Host ""
Write-Host "  $upCount / $($services.Count) services running" -ForegroundColor $(if ($upCount -eq $services.Count) { "Green" } elseif ($upCount -gt 4) { "Yellow" } else { "Red" })

# Check Docker
Write-Host ""
Write-Host "  Database" -ForegroundColor Cyan
$dbRunning = docker ps --filter "name=jads-db" --format "{{.Names}}" 2>&1
if ($dbRunning -match "jads-db") {
    Write-Host "  ✓  PostgreSQL (jads-db container running)" -ForegroundColor Green
} else {
    Write-Host "  ✗  PostgreSQL (jads-db container not running)" -ForegroundColor Red
}

# Show APK if it exists
Write-Host ""
$apkFile = Join-Path $PSScriptRoot "jads-android\app\build\outputs\apk\debug\app-debug.apk"
if (Test-Path $apkFile) {
    $apkDate = (Get-Item $apkFile).LastWriteTime.ToString("dd MMM HH:mm")
    $apkSize = [math]::Round((Get-Item $apkFile).Length / 1MB, 1)
    Write-Host "  APK" -ForegroundColor Cyan
    Write-Host "  ✓  app-debug.apk  $apkSize MB  (built $apkDate)" -ForegroundColor Green
    Write-Host "     $apkFile" -ForegroundColor Gray
} else {
    Write-Host "  APK  — not built yet (run .\start-jads.ps1)" -ForegroundColor Yellow
}

Write-Host ""
