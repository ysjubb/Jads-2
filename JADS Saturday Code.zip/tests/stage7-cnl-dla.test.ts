// AFTN CNL + DLA builder tests — no database required.
// Drop into: jads-backend/src/__tests__/stage7-cnl-dla.test.ts
// Run with: npx jest stage7-cnl-dla --no-coverage

import { AftnCnlBuilder } from '../../services/AftnCnlBuilder'
import { AftnDlaBuilder } from '../../services/AftnDlaBuilder'

const cnl = new AftnCnlBuilder()
const dla = new AftnDlaBuilder()

// ── CNL BUILDER ──────────────────────────────────────────────────────────────

describe('AftnCnlBuilder', () => {

  describe('valid CNL messages', () => {

    test('basic CNL — no reason', () => {
      const result = cnl.build({
        callsign:      'VTABC',
        departureIcao: 'VIDP',
        eobt:          '151430',
        destination:   'VOMM',
        atsRef:        'STUB-A1B2C3',
      })
      expect(result.message).toMatch(/^\(CNL-/)
      expect(result.message).toMatch(/\)$/)
      expect(result.message).toContain('VTABC')
      expect(result.message).toContain('VIDP')
      expect(result.message).toContain('151430')
      expect(result.message).toContain('VOMM')
      expect(result.atsRef).toBe('STUB-A1B2C3')
      expect(result.cancellationUtc).toBeTruthy()
    })

    test('CNL with reason — reason appears in message', () => {
      const result = cnl.build({
        callsign:      'IAF123',
        departureIcao: 'VOBL',
        eobt:          '201000',
        destination:   'VIDP',
        atsRef:        'STUB-XYZ',
        reason:        'Weather hold — thunderstorm',
      })
      expect(result.message).toContain('RMK/')
      expect(result.message).toContain('WEATHER HOLD')
    })

    test('reason sanitisation — hyphens and parens removed', () => {
      const result = cnl.build({
        callsign:      'VTXYZ',
        departureIcao: 'VABB',
        eobt:          '010800',
        destination:   'VOHS',
        atsRef:        'STUB-001',
        reason:        'Cancelled (crew rest) - operational',
      })
      // Hyphens and parens should not appear in the reason text
      const reasonPart = result.message.split('RMK/')[1] ?? ''
      expect(reasonPart).not.toContain('(')
      expect(reasonPart).not.toContain(')')
    })

    test('reason truncated to 64 characters', () => {
      const longReason = 'A'.repeat(100)
      const result = cnl.build({
        callsign:      'VTABC',
        departureIcao: 'VIDP',
        eobt:          '151430',
        destination:   'VOMM',
        atsRef:        'STUB-001',
        reason:        longReason,
      })
      const reasonPart = result.message.split('RMK/')[1] ?? ''
      expect(reasonPart.trim().length).toBeLessThanOrEqual(68) // 64 + space + "A"
    })

    test('cancellationUtc is a valid ISO string', () => {
      const result = cnl.build({
        callsign: 'VTABC', departureIcao: 'VIDP',
        eobt: '151430', destination: 'VOMM', atsRef: 'STUB-001',
      })
      expect(() => new Date(result.cancellationUtc)).not.toThrow()
      expect(new Date(result.cancellationUtc).toISOString()).toBe(result.cancellationUtc)
    })

    test('military callsign format accepted', () => {
      const result = cnl.build({
        callsign:      'IAF28SQ',
        departureIcao: 'VIAG',
        eobt:          '010600',
        destination:   'VIDP',
        atsRef:        'STUB-MIL001',
      })
      expect(result.message).toContain('IAF28SQ')
    })

  })

  describe('CNL validation errors', () => {

    test('throws when atsRef is missing', () => {
      expect(() => cnl.build({
        callsign: 'VTABC', departureIcao: 'VIDP',
        eobt: '151430', destination: 'VOMM', atsRef: '',
      })).toThrow('CNL_REQUIRES_ATS_REF')
    })

    test('throws on invalid callsign', () => {
      expect(() => cnl.build({
        callsign: 'vt-abc!', departureIcao: 'VIDP',
        eobt: '151430', destination: 'VOMM', atsRef: 'STUB-001',
      })).toThrow('CNL_INVALID_CALLSIGN')
    })

    test('throws on 3-letter ADEP', () => {
      expect(() => cnl.build({
        callsign: 'VTABC', departureIcao: 'DEL',
        eobt: '151430', destination: 'VOMM', atsRef: 'STUB-001',
      })).toThrow('CNL_INVALID_ADEP')
    })

    test('throws on invalid EOBT format', () => {
      expect(() => cnl.build({
        callsign: 'VTABC', departureIcao: 'VIDP',
        eobt: '14:30', destination: 'VOMM', atsRef: 'STUB-001',
      })).toThrow('CNL_INVALID_EOBT')
    })

    test('throws on invalid destination', () => {
      expect(() => cnl.build({
        callsign: 'VTABC', departureIcao: 'VIDP',
        eobt: '151430', destination: 'BOM', atsRef: 'STUB-001',
      })).toThrow('CNL_INVALID_ADES')
    })

  })

})

// ── DLA BUILDER ──────────────────────────────────────────────────────────────

describe('AftnDlaBuilder', () => {

  describe('valid DLA messages', () => {

    test('basic DLA — 30 minute delay', () => {
      const result = dla.build({
        callsign:      'VTABC',
        departureIcao: 'VIDP',
        originalEobt:  '151430',
        newEobt:       '151500',
        destination:   'VOMM',
        atsRef:        'STUB-A1B2C3',
      })
      expect(result.message).toMatch(/^\(DLA-/)
      expect(result.message).toMatch(/\)$/)
      expect(result.message).toContain('VTABC')
      expect(result.message).toContain('151430')
      expect(result.message).toContain('151500')
      expect(result.originalEobt).toBe('151430')
      expect(result.newEobt).toBe('151500')
    })

    test('DLA with reason — reason appears as RMK/', () => {
      const result = dla.build({
        callsign:      'VTXYZ',
        departureIcao: 'VABB',
        originalEobt:  '010800',
        newEobt:       '010930',
        destination:   'VOBL',
        atsRef:        'STUB-002',
        reason:        'Ground hold ATC',
      })
      expect(result.message).toContain('RMK/')
      expect(result.message).toContain('GROUND HOLD ATC')
    })

    test('large delay — next day EOBT', () => {
      // Day 15 at 23:00 delayed to Day 16 at 02:00
      const result = dla.build({
        callsign:      'VTABC',
        departureIcao: 'VIDP',
        originalEobt:  '152300',
        newEobt:       '160200',
        destination:   'VOMM',
        atsRef:        'STUB-003',
      })
      expect(result.message).toContain('152300')
      expect(result.message).toContain('160200')
    })

    test('builtAtUtc is valid ISO string', () => {
      const result = dla.build({
        callsign: 'VTABC', departureIcao: 'VIDP',
        originalEobt: '151430', newEobt: '151530',
        destination: 'VOMM', atsRef: 'STUB-001',
      })
      expect(() => new Date(result.builtAtUtc)).not.toThrow()
    })

    test('reason sanitisation — hyphens removed', () => {
      const result = dla.build({
        callsign: 'VTABC', departureIcao: 'VIDP',
        originalEobt: '151430', newEobt: '151600',
        destination: 'VOMM', atsRef: 'STUB-001',
        reason: 'Crew late - awaiting crew',
      })
      const reasonPart = result.message.split('RMK/')[1] ?? ''
      expect(reasonPart).not.toContain('-')
    })

  })

  describe('DLA validation errors', () => {

    test('throws when atsRef missing', () => {
      expect(() => dla.build({
        callsign: 'VTABC', departureIcao: 'VIDP',
        originalEobt: '151430', newEobt: '151500',
        destination: 'VOMM', atsRef: '',
      })).toThrow('DLA_REQUIRES_ATS_REF')
    })

    test('throws when newEobt is same as originalEobt', () => {
      expect(() => dla.build({
        callsign: 'VTABC', departureIcao: 'VIDP',
        originalEobt: '151430', newEobt: '151430',
        destination: 'VOMM', atsRef: 'STUB-001',
      })).toThrow('DLA_NEW_EOBT_NOT_LATER')
    })

    test('throws when newEobt is earlier than originalEobt', () => {
      expect(() => dla.build({
        callsign: 'VTABC', departureIcao: 'VIDP',
        originalEobt: '151430', newEobt: '151400',
        destination: 'VOMM', atsRef: 'STUB-001',
      })).toThrow('DLA_NEW_EOBT_NOT_LATER')
    })

    test('throws on invalid EOBT format', () => {
      expect(() => dla.build({
        callsign: 'VTABC', departureIcao: 'VIDP',
        originalEobt: '14:30', newEobt: '15:00',
        destination: 'VOMM', atsRef: 'STUB-001',
      })).toThrow('DLA_INVALID_ORIGINAL_EOBT')
    })

    test('throws on invalid callsign', () => {
      expect(() => dla.build({
        callsign: 'bad callsign!', departureIcao: 'VIDP',
        originalEobt: '151430', newEobt: '151600',
        destination: 'VOMM', atsRef: 'STUB-001',
      })).toThrow('DLA_INVALID_CALLSIGN')
    })

  })

})
